import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Download, MessageSquare, Save, Send, Undo2 } from "lucide-react";
import { AppShell, StatusPill, statusStepClasses } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { AggregateForm, exportCsv, fieldClass } from "@/components/AggregateForm";
import { useEvaluations } from "@/components/evaluation-context";
import {
  STATUS,
  MAIN_STEPS,
  mainStage,
  ROLES,
  stageRole,
  officeFor,
  appendixFor,
  selfEditable,
  totalScore,
  allocatedTotal,
  cqttTotal,
  templateResult,
  getEvaluation,
  type Evaluation,
  type Criterion,
  type Action,
  type Draft,
} from "@/lib/evaluation";
import { cn } from "@/lib/utils";
export const Route = createFileRoute("/danh-gia/$id")({
  loader: ({ params }) => getEvaluation(params.id) ?? null,
  head: () => ({ meta: [{ title: "Phiếu đánh giá — vOffice" }] }),
  component: Detail,
});
function Detail() {
  const { evaluations, previewRole } = useEvaluations();
  const { id } = Route.useParams();
  const loaded = Route.useLoaderData();
  const ev = evaluations.find((e) => e.id === id) ?? loaded;
  if (!ev) throw notFound();
  return (
    <EvaluationDetail
      key={`${ev.id}-${ev.updated}-${ev.history?.length ?? 0}-${ev.step}-${previewRole}`}
      ev={ev}
    />
  );
}
export function EvaluationDetail({ ev }: { ev: Evaluation }) {
  const { previewRole, updateEvaluation } = useEvaluations();
  const [tab, setTab] = useState<"personal" | "kpi" | "ki" | "appendix" | "assignment">(
    ["council", "council_adjust", "ceo"].includes(ev.step)
      ? "ki"
      : ["cqtt", "cqtt_report", "office"].includes(ev.step)
        ? "kpi"
        : "personal",
  );
  const [items, setItems] = useState<Criterion[]>(ev.criteria.map((c) => ({ ...c })));
  const [aggregateDraft, setAggregateDraft] = useState<Draft>({});
  const [note, setNote] = useState("");
  const [response, setResponse] = useState<"Tiếp thu" | "Bảo lưu">(ev.response ?? "Tiếp thu");
  const [responseNote, setResponseNote] = useState(ev.responseNote ?? "");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const own = stageRole[ev.step] === previewRole;
  const canSelf = selfEditable(ev, previewRole);
  const canRespond = own && ev.step === "response";
  const result = templateResult(ev);
  const run = (action?: Action) => {
    let patch: Draft =
      own && ["cqtt", "council", "council_adjust"].includes(ev.step) ? aggregateDraft : {};
    if (canSelf) patch = { criteria: items };
    else if (canRespond) patch = { criteria: items, response, responseNote };
    else if (action === "return") patch = { note };
    else if (ev.step === "cqtt" && own && note.trim()) patch = { ...patch, note };
    const issue = updateEvaluation(ev.id, patch, action);
    setError(issue ?? "");
    setMessage(issue ? "" : action ? "Đã chuyển hồ sơ." : "Đã lưu nháp.");
  };
  const actions: { action: Action; label: string; outline?: boolean }[] = !own
    ? []
    : ["self", "office_return"].includes(ev.step)
      ? [{ action: "submit", label: `Gửi ${officeFor(ev)} tổng hợp` }]
      : ev.step === "office"
        ? [
            { action: "return", label: "Gửi lại CQĐV/CQ điều chỉnh", outline: true },
            { action: "send", label: "Gửi CQTT rà soát" },
          ]
        : ev.step === "cqtt"
          ? [
              { action: "request", label: "Yêu cầu tiếp thu / bảo lưu", outline: true },
              { action: "finish", label: "Hoàn tất rà soát" },
            ]
          : ev.step === "response"
            ? [{ action: "respond", label: "Gửi phản hồi CQTT" }]
            : ev.step === "cqtt_report"
              ? [{ action: "send", label: "Gửi báo cáo Hội đồng" }]
              : ["council", "council_adjust"].includes(ev.step)
                ? [
                    {
                      action: "submit",
                      label: ev.step === "council_adjust" ? "Trình lại TGĐ" : "Trình TGĐ",
                    },
                  ]
                : ev.step === "ceo"
                  ? [
                      { action: "return", label: "Yêu cầu Hội đồng điều chỉnh", outline: true },
                      { action: "approve", label: "Phê duyệt" },
                    ]
                  : ev.step === "approved"
                    ? [{ action: "send", label: `Gửi kết quả về ${officeFor(ev)}` }]
                    : ev.step === "dispatch"
                      ? [{ action: "send", label: "Gửi kết quả CQĐV/CQ" }]
                      : ev.step === "sign"
                        ? [{ action: "sign", label: "Trình ký phiếu ĐG kèm phiếu GNV" }]
                        : [];
  function downloadTemplate() {
    exportCsv(`Template-${ev.id}`, [
      ["Phiếu", ev.id],
      ["Cá nhân", ev.owner],
      ["Đơn vị", ev.unit],
      ["Kỳ", ev.period],
      ["Phiếu GNV", ev.assignmentRef],
      ["Điểm Hội đồng", result.score],
      ["Ki", result.ki],
      ["Mức độ hoàn thành", result.completion],
      [],
      [
        "Mục tiêu",
        "KPI",
        "Phương pháp đo",
        "Đơn vị",
        "Tỷ trọng",
        "T",
        "B",
        "S",
        "Ngày bắt đầu",
        "Ngày hoàn thành",
        "Kết quả",
        "CBNV tự đánh giá",
        "QLTT đánh giá (tự phân bổ)",
      ],
      ...ev.criteria.map((c) => [
        c.goal,
        c.kpi,
        c.method,
        c.unit,
        c.weight,
        c.target.t,
        c.target.b,
        c.target.s,
        c.startDate,
        c.endDate,
        c.result,
        c.self,
        c.council,
      ]),
    ]);
  }
  const active = mainStage(ev.step);
  const activeIndex = MAIN_STEPS.findIndex((s) => s.key === active);
  return (
    <AppShell
      crumbs={
        <>
          <Link to="/">Đánh giá</Link>
          <span>›</span>
          <span>{ev.id}</span>
        </>
      }
      title={`Phiếu đánh giá – ${ev.unit}`}
      actions={
        <>
          <Button variant="outline" onClick={downloadTemplate}>
            <Download />
            Xuất template CSV
          </Button>
          {(canSelf || canRespond) && (
            <Button variant="outline" onClick={() => run()}>
              <Save />
              Lưu nháp
            </Button>
          )}
          {actions.map((a) => (
            <Button
              key={a.action}
              variant={a.outline ? "outline" : "default"}
              onClick={() => run(a.action)}
            >
              {a.outline ? <Undo2 /> : a.action === "approve" ? <Check /> : <Send />}
              {a.label}
            </Button>
          ))}
        </>
      }
    >
      {error && (
        <p role="alert" className="mb-4 rounded-md border border-primary p-3 text-sm text-primary">
          {error}
        </p>
      )}
      {message && (
        <p role="status" className="mb-4 text-sm text-success">
          {message}
        </p>
      )}
      <ol
        aria-label="Tiến trình đánh giá"
        className="mb-5 flex overflow-x-auto rounded-lg border p-4"
      >
        {MAIN_STEPS.map((s, i) => {
          const complete = i < activeIndex || active === "approved";
          const current = s.key === active;
          return (
            <li
              key={s.key}
              aria-current={current ? "step" : undefined}
              className="flex min-w-44 flex-1 items-center gap-3"
            >
              <span
                className={cn(
                  "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-sm font-semibold",
                  complete
                    ? "border-success bg-success text-primary-foreground"
                    : current
                      ? statusStepClasses[STATUS[ev.step].tone]
                      : "border-border text-muted-foreground",
                )}
              >
                {complete ? <Check className="h-4 w-4" /> : i + 1}
              </span>
              <div className="text-xs leading-tight">
                <div
                  className={cn(
                    "font-medium",
                    current && !complete && "font-semibold text-foreground",
                  )}
                >
                  {s.label}
                </div>
                <div className="mt-0.5 text-muted-foreground">
                  {s.key === "office" ? officeFor(ev) : s.actor}
                </div>
              </div>
              {i < MAIN_STEPS.length - 1 && (
                <div
                  className={cn("mx-1 h-px min-w-5 flex-1", complete ? "bg-success" : "bg-border")}
                />
              )}
            </li>
          );
        })}
      </ol>
      {!own && ev.step !== "done" && (
        <p className="mb-4 text-sm text-muted-foreground">
          Chế độ xem. Chọn vai trò {ROLES[stageRole[ev.step]]} để xử lý bước hiện tại.
        </p>
      )}
      {canRespond && (
        <section className="mb-5 space-y-3 rounded-lg border p-4">
          <h2 className="font-semibold">Phản hồi CQTT</h2>
          <label className="block text-sm">
            Hình thức phản hồi{" "}
            <select
              aria-label="Hình thức phản hồi"
              className={fieldClass}
              value={response}
              onChange={(e) => setResponse(e.target.value as "Tiếp thu" | "Bảo lưu")}
            >
              <option>Tiếp thu</option>
              <option>Bảo lưu</option>
            </select>
          </label>
          <textarea
            aria-label="Nội dung phản hồi"
            className="min-h-24 w-full rounded-md border p-3 text-sm"
            value={responseNote}
            onChange={(e) => setResponseNote(e.target.value)}
            placeholder="Nội dung tiếp thu hoặc giải trình bảo lưu..."
          />
          <p className="text-xs text-muted-foreground">
            Bổ sung kết quả thực hiện tại tab Template cá nhân. Điểm tự đánh giá và điểm CQTT giữ
            nguyên.
          </p>
        </section>
      )}
      {own && ["cqtt", "council", "council_adjust"].includes(ev.step) && (
        <p className="mb-4 text-sm text-info">
          Thay đổi trên bảng tổng hợp được lưu khi chọn Lưu dòng hoặc chuyển bước/trình duyệt.
        </p>
      )}
      <div className="grid grid-cols-1 items-start gap-5 xl:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0">
          <div className="mb-4 grid grid-cols-2 gap-4 rounded-lg bg-muted/60 p-4 text-sm lg:grid-cols-4">
            <div>
              <div className="text-xs text-muted-foreground">Kỳ đánh giá</div>
              <div className="mt-1 font-medium">{ev.period}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Khối</div>
              <div className="mt-1 font-medium">{ev.block}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Người thực hiện</div>
              <div className="mt-1 font-medium">{ev.owner}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Trạng thái</div>
              <div className="mt-1">
                <StatusPill tone={STATUS[ev.step].tone}>{STATUS[ev.step].label}</StatusPill>
              </div>
            </div>
          </div>
          <div
            className="mb-4 flex flex-wrap gap-1 border-b"
            role="tablist"
            aria-label="Form hồ sơ"
          >
            {(
              [
                ["personal", "Template cá nhân"],
                ["kpi", "Tổng hợp đánh giá"],
                ["ki", "Tổng hợp KPI"],
                ["appendix", appendixFor(ev)],
                ["assignment", "Phiếu giao nhiệm vụ"],
              ] as const
            )
              .filter(([key]) => ev.step !== "office" || key === "personal" || key === "kpi")
              .map(([key, label]) => (
                <button
                  role="tab"
                  aria-selected={tab === key}
                  key={key}
                  onClick={() => setTab(key)}
                  className={cn(
                    "px-4 py-3 text-sm",
                    tab === key
                      ? "border-b-2 border-primary font-semibold text-primary"
                      : "text-muted-foreground",
                  )}
                >
                  {label}
                </button>
              ))}
          </div>
          {tab === "kpi" || tab === "ki" || tab === "appendix" ? (
            <AggregateForm evaluations={[ev]} mode={tab} onDraftChange={setAggregateDraft} />
          ) : (
            <section className="space-y-4">
              <details className="rounded-lg border p-3 text-sm">
                <summary className="cursor-pointer text-muted-foreground">
                  Thông tin cá nhân và phiếu giao nhiệm vụ
                </summary>
                <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {[
                    ["Họ tên", ev.owner],
                    ["Mã nhân viên", ev.employeeId],
                    ["Chức danh", ev.jobTitle],
                    ["Địa điểm", ev.location],
                    ["Đơn vị", ev.unit],
                    ["Kỳ đánh giá", ev.period],
                    ["Phiếu GNV", ev.assignmentRef],
                    ["Đầu mối", officeFor(ev)],
                  ].map(([label, value]) => (
                    <div key={label}>
                      <div className="text-xs text-muted-foreground">{label}</div>
                      <div className="mt-1 font-medium">{value ?? "—"}</div>
                    </div>
                  ))}
                </div>
              </details>
              <PersonalTable
                items={items}
                assignment={tab === "assignment"}
                canSelf={canSelf && tab === "personal"}
                canResult={(canSelf || canRespond) && tab === "personal"}
                onChange={setItems}
              />
              {tab === "personal" && (
                <p className="text-xs text-muted-foreground">
                  Cột QLTT đánh giá được tự phân bổ từ tổng điểm Hội đồng trên Tổng hợp KPI; giữ
                  nguyên điểm tự đánh giá và tỷ trọng.
                </p>
              )}
            </section>
          )}
        </div>
        <aside className="space-y-4" aria-label="Kết quả và ý kiến đánh giá">
          <section className="rounded-lg border p-4 text-center">
            <div className="text-xs text-muted-foreground">
              {["approved", "dispatch", "sign", "done"].includes(ev.step)
                ? "Xếp loại đã phê duyệt"
                : "Xếp loại dự kiến"}
            </div>
            <div className="mt-1 text-5xl font-bold text-primary">{result.ki}</div>
            <div className="mt-1 text-sm font-medium">
              {result.score === null && result.ki === "—" ? "Chưa có đánh giá" : result.rating}
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 border-t pt-3 text-sm">
              <div>
                <div className="text-xs text-muted-foreground">Tự ĐG</div>
                <div className="font-semibold">{totalScore(items).toFixed(2)}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">CQTT</div>
                <div className="font-semibold">{cqttTotal(ev)?.toFixed(2) ?? "—"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Hội đồng</div>
                <div className="font-semibold">{result.score?.toFixed(2) ?? "—"}</div>
              </div>
            </div>
            <div className="mt-3 border-t pt-3 text-xs text-muted-foreground">
              {result.completion}
            </div>
          </section>
          <section className="rounded-lg border p-4 text-sm">
            <h2 className="mb-3 font-medium">Đánh giá tuân thủ</h2>
            {(
              [
                ["Địa điểm làm việc", ev.locationCompliance],
                ["Nội quy lao động", ev.laborCompliance],
                ["Văn hoá Viettel", ev.cultureCompliance],
              ] as const
            ).map(([label, value]) => (
              <label key={label} className="mb-2 flex items-start justify-between gap-2 text-xs">
                <span className="pt-1">{label}</span>
                <select
                  aria-label={label}
                  disabled
                  value={value ?? ""}
                  className="max-w-36 rounded border bg-card px-2 py-1 text-xs"
                >
                  <option value="">—</option>
                  {[
                    "Tuân thủ",
                    "Không tuân thủ",
                    "Vi phạm nhưng chưa đến mức bị xử lý kỷ luật",
                    "Bị xử lý kỷ luật lao động",
                  ].map((v) => (
                    <option key={v}>{v}</option>
                  ))}
                </select>
              </label>
            ))}
            <p className="mt-3 text-xs text-muted-foreground">Kết quả từ Tổng hợp KPI.</p>
          </section>
          <section className="rounded-lg border p-4 text-sm">
            <h2 className="mb-3 flex items-center gap-2 font-medium">
              <MessageSquare className="h-4 w-4" />Ý kiến xử lý
            </h2>
            {ev.history?.slice(-3).map((h, i) => (
              <div key={i} className="mb-2 rounded bg-muted p-2 text-xs">
                <b>{ROLES[h.role]}</b> · {h.at}
                <div className="mt-1 whitespace-pre-wrap">{h.note || actionLabel(h.action)}</div>
              </div>
            ))}
            {ev.note && (
              <div className="mb-3 rounded-md bg-muted p-2 text-xs">
                <b>Ý kiến / yêu cầu đã ghi nhận:</b>
                <p className="mt-1 whitespace-pre-wrap">{ev.note}</p>
              </div>
            )}
            {ev.response && (
              <p className="mb-3 rounded-md bg-muted p-2 text-xs">
                <b>{ev.response}:</b> {ev.responseNote} · Điểm CQTT được giữ nguyên.
              </p>
            )}
            {own && ["office", "ceo", "cqtt"].includes(ev.step) && (
              <label className="block text-xs">
                {ev.step === "ceo"
                  ? "Chỉ đạo điều chỉnh của TGĐ"
                  : ev.step === "office"
                    ? "Lý do gửi lại CQĐV/CQ"
                    : "Nội dung yêu cầu phản hồi (để trống để dùng góp ý đã lưu)"}
                <textarea
                  aria-label="Lý do điều chỉnh"
                  className="mt-2 block min-h-20 w-full rounded-md border p-2 text-sm"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Nhập nội dung cụ thể..."
                />
              </label>
            )}

            {!ev.note &&
              !ev.response &&
              !ev.history?.length &&
              !["office", "ceo", "cqtt"].includes(ev.step) && (
                <p className="text-xs text-muted-foreground">Chưa có ý kiến xử lý.</p>
              )}
          </section>
        </aside>
      </div>
      <section className="mt-6 rounded-lg border p-4">
        <h2 className="mb-3 font-semibold">Lịch sử xử lý</h2>
        {!ev.history?.length && (
          <p className="text-sm text-muted-foreground">Dữ liệu mẫu chưa có lịch sử thao tác.</p>
        )}
        {ev.history?.map((h, i) => (
          <details key={i} className="border-t py-3 text-sm">
            <summary className="cursor-pointer">
              {h.at} · {ROLES[h.role]} · {actionLabel(h.action)} {h.note && `— ${h.note}`}
            </summary>
            <div className="mt-2 grid gap-2 text-xs md:grid-cols-2">
              <pre className="overflow-auto rounded bg-muted p-3">Trước: {h.before}</pre>
              <pre className="overflow-auto rounded bg-muted p-3">Sau: {h.after}</pre>
            </div>
          </details>
        ))}
      </section>
      {ev.step === "done" && (
        <p className="mt-4 text-sm text-success">
          Đã ghi nhận trình ký phiếu đánh giá kèm {ev.assignmentRef ?? "phiếu GNV"}. Bản mẫu chưa
          kết nối dịch vụ ký số.
        </p>
      )}
    </AppShell>
  );
}
function actionLabel(action: string) {
  return (
    (
      {
        submit: "Gửi hồ sơ",
        send: "Chuyển hồ sơ",
        return: "Yêu cầu điều chỉnh",
        request: "Yêu cầu phản hồi",
        respond: "Gửi phản hồi",
        finish: "Hoàn tất rà soát",
        approve: "Phê duyệt",
        sign: "Trình ký",
      } as Record<string, string>
    )[action] ?? action
  );
}
function PersonalTable({
  items,
  assignment,
  canSelf,
  canResult,
  onChange,
}: {
  items: Criterion[];
  assignment: boolean;
  canSelf: boolean;
  canResult: boolean;
  onChange: (items: Criterion[]) => void;
}) {
  const update = (index: number, patch: Partial<Criterion>) =>
    onChange(items.map((c, i) => (i === index ? { ...c, ...patch } : c)));
  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="w-full min-w-[1250px] text-left text-sm">
        <thead className="bg-muted text-xs">
          <tr>
            {[
              "Mục tiêu nhiệm vụ/công việc",
              "Chỉ số đo lường KPI",
              "Phương pháp đo",
              "Đơn vị đo",
              "Tỷ trọng",
            ].map((h) => (
              <th key={h} rowSpan={2} className="px-2 py-3 font-medium">
                {h}
              </th>
            ))}
            <th colSpan={3} className="border-b px-2 py-2 text-center font-medium">
              Các mức chỉ tiêu
            </th>
            {[
              "Ngày bắt đầu",
              "Ngày hoàn thành",
              ...(assignment
                ? []
                : ["Kết quả thực hiện", "CBNV tự đánh giá", "QLTT đánh giá (tự phân bổ)"]),
            ].map((h) => (
              <th key={h} rowSpan={2} className="px-2 py-3 font-medium">
                {h}
              </th>
            ))}
          </tr>
          <tr>
            {["T", "B", "S"].map((h) => (
              <th key={h} className="px-2 py-2 text-center font-medium text-muted-foreground">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {(
            [
              ["A", "A. Nhiệm vụ trọng tâm"],
              ["B-I", "B.I. Mục tiêu theo chức năng"],
              ["B-II", "B.II. Kiểm soát ngành dọc"],
            ] as const
          ).map(([group, label]) => (
            <GroupRows
              key={group}
              label={label}
              rows={items.map((c, i) => ({ c, i })).filter(({ c }) => c.group === group)}
              assignment={assignment}
              canSelf={canSelf}
              canResult={canResult}
              update={update}
            />
          ))}
          <tr className="bg-muted font-semibold">
            <td colSpan={4} className="p-3">
              Tổng tỷ trọng
            </td>
            <td>{Math.round(items.reduce((s, c) => s + c.weight, 0) * 100)}%</td>
            <td colSpan={assignment ? 5 : 6}>{!assignment && "Σ Tỷ trọng × Điểm"}</td>
            {!assignment && (
              <>
                <td className="px-3">{totalScore(items).toFixed(2)}</td>
                <td className="px-3 text-primary">{allocatedTotal(items)?.toFixed(2) ?? "—"}</td>
              </>
            )}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
function GroupRows({
  label,
  rows,
  assignment,
  canSelf,
  canResult,
  update,
}: {
  label: string;
  rows: { c: Criterion; i: number }[];
  assignment: boolean;
  canSelf: boolean;
  canResult: boolean;
  update: (i: number, patch: Partial<Criterion>) => void;
}) {
  const date = (v: string | undefined) => (v ? v.split("-").reverse().join("/") : "—");
  return (
    <>
      <tr className="bg-accent/50 text-primary">
        <td colSpan={assignment ? 10 : 13} className="px-2 py-2 text-xs font-semibold">
          {label}
        </td>
      </tr>
      {rows.map(({ c, i }) => (
        <tr className="border-t" key={i}>
          <td className="sticky left-0 min-w-56 bg-card px-3 py-3 font-medium">{c.goal}</td>
          <td className="px-2">
            <input
              aria-label={`Chỉ số đo lường KPI mục tiêu ${i + 1}`}
              readOnly
              value={c.kpi}
              className={fieldClass + " my-2 w-44"}
            />
          </td>
          <td className="px-2">
            <input
              aria-label={`Phương pháp đo mục tiêu ${i + 1}`}
              readOnly
              value={c.method ?? ""}
              placeholder="Công thức / cách tính"
              className={fieldClass + " my-2 w-40"}
            />
          </td>
          <td className="px-2">
            <input
              aria-label={`Đơn vị đo mục tiêu ${i + 1}`}
              readOnly
              value={c.unit}
              className={fieldClass + " my-2 w-24"}
            />
          </td>
          <td className="px-3">{Math.round(c.weight * 100)}%</td>
          <td className="px-3">{c.target.t}</td>
          <td className="px-3">{c.target.b}</td>
          <td className="px-3">{c.target.s}</td>
          <td className="whitespace-nowrap px-3">{date(c.startDate)}</td>
          <td className="whitespace-nowrap px-3">{date(c.endDate)}</td>
          {!assignment && (
            <>
              <td className="px-3">
                {canResult ? (
                  <textarea
                    aria-label={`Kết quả thực hiện mục tiêu ${i + 1}`}
                    rows={1}
                    className="my-2 h-9 min-w-48 rounded-md border px-2 py-1.5"
                    value={c.result}
                    onChange={(e) => update(i, { result: e.target.value })}
                  />
                ) : (
                  <input
                    aria-label={`Kết quả thực hiện mục tiêu ${i + 1}`}
                    readOnly
                    value={c.result}
                    className={fieldClass + " my-2 min-w-48"}
                  />
                )}
              </td>
              <td className="px-3">
                {canSelf ? (
                  <select
                    aria-label={`Tự đánh giá mục tiêu ${i + 1}`}
                    className={fieldClass}
                    value={c.self}
                    onChange={(e) => update(i, { self: Number(e.target.value) })}
                  >
                    <option value={0}>—</option>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <option key={n}>{n}</option>
                    ))}
                  </select>
                ) : (
                  c.self || "—"
                )}
              </td>
              <td
                className="px-3 font-medium text-primary"
                aria-label={`Điểm phân bổ mục tiêu ${i + 1}`}
              >
                {c.council?.toFixed(4) ?? "—"}
              </td>
            </>
          )}
        </tr>
      ))}
    </>
  );
}
