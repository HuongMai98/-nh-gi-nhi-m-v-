# Evaluation workflow
- [x] Remove the independent manager review stage and role.
- [x] Office return/resubmit and CQTT acceptance/reservation.
- [x] CQTT scores aggregate KPI; council inherits total and edits Tong hop Ki only.
- [x] Personal template derives council summary without task-level manager scoring.
- [x] CEO corrections, approval, result delivery and signature submission preview.
- [x] Role/stage validation, field locks, immutable score history and CSV export.
- [x] TypeScript, workflow tests, UI tests and production build.
