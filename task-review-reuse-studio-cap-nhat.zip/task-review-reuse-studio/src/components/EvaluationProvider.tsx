import { useState, type ReactNode } from "react";
import {
  EVALUATIONS,
  saveDraft,
  transition,
  type PreviewRole,
  type Draft,
  type Action,
} from "@/lib/evaluation";
import { EvaluationContext } from "@/components/evaluation-context";
export function EvaluationProvider({ children }: { children: ReactNode }) {
  const [evaluations, setEvaluations] = useState(EVALUATIONS);
  const [previewRole, setPreviewRole] = useState<PreviewRole>("performer");
  function updateEvaluation(id: string, patch: Draft, action?: Action): string | null {
    const e = evaluations.find((item) => item.id === id);
    if (!e) return "Không tìm thấy hồ sơ.";
    try {
      const now = new Date().toLocaleString("vi-VN");
      const returnAction = action === "return";
      const editable = Object.keys(patch).length > 0 && !returnAction;
      const saved = editable ? saveDraft(e, previewRole, patch, now) : e;
      const next = action
        ? transition(saved, previewRole, action, returnAction ? patch : {}, now)
        : saved;
      setEvaluations((current) => current.map((item) => (item.id === id ? next : item)));
      return null;
    } catch (error) {
      return error instanceof Error ? error.message : "Không thể cập nhật hồ sơ.";
    }
  }
  return (
    <EvaluationContext.Provider
      value={{
        evaluations,
        previewRole,
        setPreviewRole,
        updateEvaluation,
        addEvaluation: (e) => setEvaluations((current) => [e, ...current]),
      }}
    >
      {children}
    </EvaluationContext.Provider>
  );
}
