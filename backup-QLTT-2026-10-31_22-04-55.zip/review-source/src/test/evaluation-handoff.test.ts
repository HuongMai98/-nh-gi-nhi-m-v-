import { describe, expect, it } from "vitest";
import { EVALUATIONS, saveDraft, transition, templateResult, kiError } from "@/lib/evaluation";
const pending = EVALUATIONS[3]!;
const sent = () => transition(pending, "performer", "submit", {}, "now");
describe("evaluation workflow", () => {
  it("submits directly to aggregation and supports office return/resubmission", () => {
    const office = sent();
    expect(office.step).toBe("office");
    expect(() => transition(office, "office", "return", {}, "now")).toThrow(/lý do/);
    const returned = transition(office, "office", "return", { note: "Bổ sung hồ sơ" }, "now");
    expect(returned.step).toBe("office_return");
    expect(transition(returned, "performer", "submit", {}, "now").step).toBe("office");
  });
  it("keeps CQTT score when receiving a reservation and inherits it for council", () => {
    let e = transition(sent(), "office", "send", {}, "now");
    e = saveDraft(
      e,
      "cqtt",
      { cqttKey: 1.4, cqttFunction: 2.7, note: "Bổ sung chứng minh" },
      "now",
    );
    e = transition(e, "cqtt", "request", {}, "now");
    e = transition(
      e,
      "performer",
      "respond",
      { response: "Bảo lưu", responseNote: "Đã có hồ sơ" },
      "now",
    );
    e = transition(e, "cqtt", "send", {}, "now");
    expect(e.councilScore).toBe(4.1);
    const revised = saveDraft(e, "council", { councilScore: 4.8, ki: "A+" }, "now");
    expect(templateResult(revised).score).toBe(4.8);
    expect(revised.cqttFunction).toBe(2.7);
    expect(revised.criteria.map((c) => c.self)).toEqual(e.criteria.map((c) => c.self));
    expect(revised.criteria.reduce((sum, c) => sum + c.weight * c.council!, 0)).toBeCloseTo(
      4.8,
      10,
    );
  });
  it("locks scores after approval and validates compliance", () => {
    const e = {
      ...pending,
      step: "council" as const,
      councilScore: 4.5,
      ki: "A+" as const,
      locationCompliance: "Không tuân thủ",
    };
    expect(kiError(e)).toMatch(/Ki D/);
    expect(() => transition(e, "council", "submit", {}, "now")).toThrow();
    const ready = { ...e, locationCompliance: "Tuân thủ", laborCompliance: "Tuân thủ" };
    const approved = transition(
      transition(ready, "council", "submit", {}, "now"),
      "ceo",
      "approve",
      {},
      "now",
    );
    expect(() => saveDraft(approved, "council", { councilScore: 5 }, "now")).toThrow();
    expect(templateResult(approved).score).toBe(4.5);
  });
});
