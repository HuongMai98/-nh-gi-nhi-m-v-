import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { AggregateForm, exportCsv, fieldClass } from "@/components/AggregateForm";
import { useEvaluations } from "@/components/evaluation-context";
import {
  STATUS,
  MAIN_STEPS,
  mainStage,
  ROLES,
  stageRole,
  officeFor,
  appendixFor,
  selfEditable,
  totalScore,
  allocatedTotal,
  cqttTotal,
  templateResult,
  getEvaluation,
  type Evaluation,
  type Criterion,
  type Action,
  type Draft,
} from "@/lib/evaluation";
import { cn } from "@/lib/utils";
export const Route = createFileRoute("/danh-gia/$id")({
  loader: ({ params }) => getEvaluation(params.id) ?? null,
  head: () => ({ meta: [{ title: "Phiếu đánh giá — vOffice" }] }),
  component: Detail,
});
function Detail() {
  const { evaluations, previewRole } = useEvaluations();
  const { id } = Route.useParams();
  const loaded = Route.useLoaderData();
  const ev = evaluations.find((e) => e.id === id) ?? loaded;
  if (!ev) throw notFound();
  return (
    <EvaluationDetail
      key={`${ev.id}-${ev.updated}-${ev.history?.length ?? 0}-${ev.step}-${previewRole}`}
      ev={ev}
    />
  );
}
export function EvaluationDetail({ ev }: { ev: Evaluation }) {
  const { previewRole, updateEvaluation } = useEvaluations();
  const [tab, setTab] = useState<"personal" | "kpi" | "ki" | "appendix" | "assignment">(
    ["council", "council_adjust", "ceo"].includes(ev.step)
      ? "ki"
      : ["cqtt", "cqtt_report", "office"].includes(ev.step)
        ? "kpi"
        : "personal",
  );
  const [items, setItems] = useState<Criterion[]>(ev.criteria.map((c) => ({ ...c })));
  const [aggregateDraft, setAggregateDraft] = useState<Draft>({});
  const [note, setNote] = useState("");
  const [response, setResponse] = useState<"Tiếp thu" | "Bảo lưu">(ev.response ?? "Tiếp thu");
  const [responseNote, setResponseNote] = useState(ev.responseNote ?? "");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const own = stageRole[ev.step] === previewRole;
  const canSelf = selfEditable(ev, previewRole);
  const canRespond = own && ev.step === "response";
  const result = templateResult(ev);
  const run = (action?: Action) => {
    let patch: Draft =
      own && ["cqtt", "council", "council_adjust"].includes(ev.step) ? aggregateDraft : {};
    if (canSelf) patch = { criteria: items };
    else if (canRespond) patch = { criteria: items, response, responseNote };
    else if (action === "return") patch = { note };
    else if (ev.step === "cqtt" && own && note.trim()) patch = { ...patch, note };
    const issue = updateEvaluation(ev.id, patch, action);
    setError(issue ?? "");
    setMessage(issue ? "" : action ? "Đã chuyển hồ sơ." : "Đã lưu nháp.");
  };
  const actions: { action: Action; label: string; outline?: boolean }[] = !own
    ? []
    : ["self", "office_return"].includes(ev.step)
      ? [{ action: "submit", label: `Gửi ${officeFor(ev)} tổng hợp` }]
      : ev.step === "office"
        ? [
            { action: "return", label: "Gửi lại CQĐV/CQ điều chỉnh", outline: true },
            { action: "send", label: "Gửi CQTT rà soát" },
          ]
        : ev.step === "cqtt"
          ? [
              { action: "request", label: "Yêu cầu tiếp thu / bảo lưu", outline: true },
              { action: "finish", label: "Hoàn tất rà soát" },
            ]
          : ev.step === "response"
            ? [{ action: "respond", label: "Gửi phản hồi CQTT" }]
            : ev.step === "cqtt_report"
              ? [{ action: "send", label: "Gửi báo cáo Hội đồng" }]
              : ["council", "council_adjust"].includes(ev.step)
                ? [
                    {
                      action: "submit",
                      label: ev.step === "council_adjust" ? "Trình lại TGĐ" : "Trình TGĐ",
                    },
                  ]
                : ev.step === "ceo"
                  ? [
                      { action: "return", label: "Yêu cầu Hội đồng điều chỉnh", outline: true },
                      { action: "approve", label: "Phê duyệt" },
                    ]
                  : ev.step === "approved"
                    ? [{ action: "send", label: `Gửi kết quả về ${officeFor(ev)}` }]
                    : ev.step === "dispatch"
                      ? [{ action: "send", label: "Gửi kết quả CQĐV/CQ" }]
                      : ev.step === "sign"
                        ? [{ action: "sign", label: "Trình ký phiếu ĐG kèm phiếu GNV" }]
                        : [];
  function downloadTemplate() {
    exportCsv(`Template-${ev.id}`, [
      ["Phiếu", ev.id],
      ["Cá nhân", ev.owner],
      ["Đơn vị", ev.unit],
      ["Kỳ", ev.period],
      ["Phiếu GNV", ev.assignmentRef],
      ["Điểm Hội đồng", result.score],
      ["Ki", result.ki],
      ["Mức độ hoàn thành", result.completion],
      [],
      [
        "Mục tiêu",
        "KPI",
        "Phương pháp đo",
        "Đơn vị",
        "Tỷ trọng",
        "T",
        "B",
        "S",
        "Ngày bắt đầu",
        "Ngày hoàn thành",
        "Kết quả",
        "CBNV tự đánh giá",
        "QLTT đánh giá (tự phân bổ)",
      ],
      ...ev.criteria.map((c) => [
        c.goal,
        c.kpi,
        c.method,
        c.unit,
        c.weight,
        c.target.t,
        c.target.b,
        c.target.s,
        c.startDate,
        c.endDate,
        c.result,
        c.self,
        c.council,
      ]),
    ]);
  }
  const active = mainStage(ev.step);
  return (
    <AppShell
      crumbs={
        <>
          <Link to="/">Đánh giá</Link>
          <span>›</span>
          <span>{ev.id}</span>
        </>
      }
      title={`Hồ sơ đánh giá — ${ev.unit}`}
      actions={
        <>
          <Button variant="outline" onClick={downloadTemplate}>
            Xuất template CSV
          </Button>
          {(canSelf || canRespond) && (
            <Button variant="outline" onClick={() => run()}>
              Lưu nháp
            </Button>
          )}
          {actions.map((a) => (
            <Button
              key={a.action}
              variant={a.outline ? "outline" : "default"}
              onClick={() => run(a.action)}
            >
              {a.label}
            </Button>
          ))}
        </>
      }
    >
      {error && (
        <p role="alert" className="mb-4 rounded-md border border-primary p-3 text-sm text-primary">
          {error}
        </p>
      )}
      {message && (
        <p role="status" className="mb-4 text-sm text-success">
          {message}
        </p>
      )}
      <div className="mb-4 flex flex-wrap items-center gap-3 rounded-md bg-muted p-3 text-sm">
        <StatusPill tone={STATUS[ev.step].tone}>{STATUS[ev.step].label}</StatusPill>
        <span>
          Đang xử lý:{" "}
          <b>{stageRole[ev.step] === "office" ? officeFor(ev) : ROLES[stageRole[ev.step]]}</b>
        </span>
        <span className="ml-auto">
          {ev.period} · {ev.block}
        </span>
      </div>
      <ol className="mb-5 flex gap-2 overflow-x-auto pb-2">
        {MAIN_STEPS.map((s, i) => (
          <li
            key={s.key}
            className={cn(
              "min-w-32 rounded-md border px-3 py-2 text-xs",
              active === s.key ? "border-primary bg-accent text-primary" : "text-muted-foreground",
            )}
          >
            <b>
              {i + 1}. {s.label}
            </b>
            <div className="mt-1">{s.actor}</div>
          </li>
        ))}
      </ol>
      {!own && ev.step !== "done" && (
        <p className="mb-4 text-sm text-muted-foreground">
          Chế độ xem. Chọn vai trò {ROLES[stageRole[ev.step]]} để xử lý bước hiện tại.
        </p>
      )}
      {ev.note && (
        <div className="mb-4 rounded-md border-l-4 border-warning bg-warning-soft p-3 text-sm">
          <b>Ý kiến / yêu cầu đã ghi nhận:</b>
          <p className="mt-1 whitespace-pre-wrap">{ev.note}</p>
        </div>
      )}
      {ev.response && (
        <p className="mb-4 rounded-md bg-muted p-3 text-sm">
          <b>{ev.response}:</b> {ev.responseNote} · Điểm CQTT được giữ nguyên.
        </p>
      )}
      {own && ["office", "ceo", "cqtt"].includes(ev.step) && (
        <label className="mb-4 block text-sm">
          {ev.step === "ceo"
            ? "Chỉ đạo điều chỉnh của TGĐ"
            : ev.step === "office"
              ? "Lý do gửi lại CQĐV/CQ"
              : "Nội dung yêu cầu phản hồi (để trống để dùng góp ý đã lưu)"}
          <textarea
            aria-label="Lý do điều chỉnh"
            className="mt-2 block min-h-20 w-full rounded-md border p-3"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Nhập nội dung cụ thể..."
          />
        </label>
      )}
      {canRespond && (
        <section className="mb-5 space-y-3 rounded-lg border p-4">
          <h2 className="font-semibold">Phản hồi CQTT</h2>
          <label className="block text-sm">
            Hình thức phản hồi{" "}
            <select
              aria-label="Hình thức phản hồi"
              className={fieldClass}
              value={response}
              onChange={(e) => setResponse(e.target.value as "Tiếp thu" | "Bảo lưu")}
            >
              <option>Tiếp thu</option>
              <option>Bảo lưu</option>
            </select>
          </label>
          <textarea
            aria-label="Nội dung phản hồi"
            className="min-h-24 w-full rounded-md border p-3 text-sm"
            value={responseNote}
            onChange={(e) => setResponseNote(e.target.value)}
            placeholder="Nội dung tiếp thu hoặc giải trình bảo lưu..."
          />
          <p className="text-xs text-muted-foreground">
            Bổ sung kết quả thực hiện tại tab Template cá nhân. Điểm tự đánh giá và điểm CQTT giữ
            nguyên.
          </p>
        </section>
      )}
      {own && ["cqtt", "council", "council_adjust"].includes(ev.step) && (
        <p className="mb-4 text-sm text-info">
          Thay đổi trên bảng tổng hợp được lưu khi chọn Lưu dòng hoặc chuyển bước/trình duyệt.
        </p>
      )}
      <div className="mb-4 flex flex-wrap gap-1 border-b" role="tablist" aria-label="Form hồ sơ">
        {(
          [
            ["personal", "Template cá nhân"],
            ["kpi", "Tổng hợp đánh giá"],
            ["ki", "Tổng hợp KPI"],
            ["appendix", appendixFor(ev)],
            ["assignment", "Phiếu giao nhiệm vụ"],
          ] as const
        )
          .filter(([key]) => ev.step !== "office" || key === "personal" || key === "kpi")
          .map(([key, label]) => (
            <button
              role="tab"
              aria-selected={tab === key}
              key={key}
              onClick={() => setTab(key)}
              className={cn(
                "px-4 py-3 text-sm",
                tab === key
                  ? "border-b-2 border-primary font-semibold text-primary"
                  : "text-muted-foreground",
              )}
            >
              {label}
            </button>
          ))}
      </div>
      {tab === "kpi" || tab === "ki" || tab === "appendix" ? (
        <AggregateForm evaluations={[ev]} mode={tab} onDraftChange={setAggregateDraft} />
      ) : (
        <section className="space-y-4">
          <div className="grid gap-3 rounded-lg bg-muted/50 p-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Họ tên", ev.owner],
              ["Mã nhân viên", ev.employeeId],
              ["Chức danh", ev.jobTitle],
              ["Địa điểm", ev.location],
              ["Đơn vị", ev.unit],
              ["Kỳ đánh giá", ev.period],
              ["Phiếu GNV", ev.assignmentRef],
              ["Đầu mối", officeFor(ev)],
            ].map(([label, value]) => (
              <div key={label}>
                <div className="text-xs text-muted-foreground">{label}</div>
                <div className="mt-1 font-medium">{value ?? "—"}</div>
              </div>
            ))}
          </div>
          {tab === "personal" && (
            <div className="grid gap-3 rounded-lg border p-4 text-sm sm:grid-cols-4">
              <div>
                Tự đánh giá<b className="mt-1 block text-xl">{totalScore(items).toFixed(2)}</b>
              </div>
              <div>
                CQTT<b className="mt-1 block text-xl">{cqttTotal(ev)?.toFixed(2) ?? "—"}</b>
              </div>
              <div>
                Điểm đánh giá Hội đồng
                <b className="mt-1 block text-xl text-primary">{result.score?.toFixed(2) ?? "—"}</b>
              </div>
              <div>
                Ki: <b>{result.ki}</b>
                <div className="mt-1">{result.completion}</div>
              </div>
              <p className="text-xs text-muted-foreground sm:col-span-4">
                Điểm Hội đồng tự phân bổ theo tỷ lệ điểm tự đánh giá, giữ trong khoảng 1–5. Tổng
                theo tỷ trọng khớp điểm Hội đồng. Điểm từng mục tiêu hiển thị 4 chữ số thập phân;
                tổng tính từ giá trị đầy đủ.
              </p>
            </div>
          )}
          <PersonalTable
            items={items}
            assignment={tab === "assignment"}
            canSelf={canSelf && tab === "personal"}
            canResult={(canSelf || canRespond) && tab === "personal"}
            onChange={setItems}
          />
          {tab === "personal" && (
            <div className="rounded-lg border p-4 text-sm">
              <h2 className="mb-2 font-semibold">Kết quả tự điền từ Tổng hợp KPI</h2>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  Xếp loại:{" "}
                  <b>
                    {result.score === null && result.ki === "—" ? "Chưa đánh giá" : result.rating}
                  </b>
                </div>
                <div>Địa điểm: {ev.locationCompliance ?? "—"}</div>
                <div>Nội quy: {ev.laborCompliance ?? "—"}</div>
              </div>
            </div>
          )}
        </section>
      )}
      <section className="mt-6 rounded-lg border p-4">
        <h2 className="mb-3 font-semibold">Lịch sử xử lý</h2>
        {!ev.history?.length && (
          <p className="text-sm text-muted-foreground">Dữ liệu mẫu chưa có lịch sử thao tác.</p>
        )}
        {ev.history?.map((h, i) => (
          <details key={i} className="border-t py-3 text-sm">
            <summary className="cursor-pointer">
              {h.at} · {ROLES[h.role]} · {actionLabel(h.action)} {h.note && `— ${h.note}`}
            </summary>
            <div className="mt-2 grid gap-2 text-xs md:grid-cols-2">
              <pre className="overflow-auto rounded bg-muted p-3">Trước: {h.before}</pre>
              <pre className="overflow-auto rounded bg-muted p-3">Sau: {h.after}</pre>
            </div>
          </details>
        ))}
      </section>
      {ev.step === "done" && (
        <p className="mt-4 text-sm text-success">
          Đã ghi nhận trình ký phiếu đánh giá kèm {ev.assignmentRef ?? "phiếu GNV"}. Bản mẫu chưa
          kết nối dịch vụ ký số.
        </p>
      )}
    </AppShell>
  );
}
function actionLabel(action: string) {
  return (
    (
      {
        submit: "Gửi hồ sơ",
        send: "Chuyển hồ sơ",
        return: "Yêu cầu điều chỉnh",
        request: "Yêu cầu phản hồi",
        respond: "Gửi phản hồi",
        finish: "Hoàn tất rà soát",
        approve: "Phê duyệt",
        sign: "Trình ký",
      } as Record<string, string>
    )[action] ?? action
  );
}
function PersonalTable({
  items,
  assignment,
  canSelf,
  canResult,
  onChange,
}: {
  items: Criterion[];
  assignment: boolean;
  canSelf: boolean;
  canResult: boolean;
  onChange: (items: Criterion[]) => void;
}) {
  const update = (index: number, patch: Partial<Criterion>) =>
    onChange(items.map((c, i) => (i === index ? { ...c, ...patch } : c)));
  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="w-full min-w-[1250px] text-left text-sm">
        <thead className="bg-muted">
          <tr>
            {[
              "Mục tiêu nhiệm vụ/công việc",
              "Chỉ số KPI",
              "Phương pháp đo",
              "Đơn vị",
              "Tỷ trọng",
              "T",
              "B",
              "S",
              "Bắt đầu",
              "Hoàn thành",
              ...(assignment
                ? []
                : ["Kết quả thực hiện", "CBNV tự đánh giá", "QLTT đánh giá (tự phân bổ)"]),
            ].map((h) => (
              <th className="px-3 py-3 font-medium" key={h}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {(
            [
              ["A", "A. Nhiệm vụ trọng tâm"],
              ["B-I", "B.I. Mục tiêu theo chức năng"],
              ["B-II", "B.II. Kiểm soát ngành dọc"],
            ] as const
          ).map(([group, label]) => (
            <GroupRows
              key={group}
              label={label}
              rows={items.map((c, i) => ({ c, i })).filter(({ c }) => c.group === group)}
              assignment={assignment}
              canSelf={canSelf}
              canResult={canResult}
              update={update}
            />
          ))}
          <tr className="bg-muted font-semibold">
            <td colSpan={4} className="p-3">
              Tổng tỷ trọng
            </td>
            <td>{Math.round(items.reduce((s, c) => s + c.weight, 0) * 100)}%</td>
            <td colSpan={assignment ? 5 : 6}>{!assignment && "Σ Tỷ trọng × Điểm"}</td>
            {!assignment && (
              <>
                <td className="px-3">{totalScore(items).toFixed(2)}</td>
                <td className="px-3 text-primary">{allocatedTotal(items)?.toFixed(2) ?? "—"}</td>
              </>
            )}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
function GroupRows({
  label,
  rows,
  assignment,
  canSelf,
  canResult,
  update,
}: {
  label: string;
  rows: { c: Criterion; i: number }[];
  assignment: boolean;
  canSelf: boolean;
  canResult: boolean;
  update: (i: number, patch: Partial<Criterion>) => void;
}) {
  const date = (v: string | undefined) => (v ? v.split("-").reverse().join("/") : "—");
  return (
    <>
      <tr className="bg-accent/50">
        <td colSpan={assignment ? 10 : 13} className="p-3 font-semibold">
          {label}
        </td>
      </tr>
      {rows.map(({ c, i }) => (
        <tr className="border-t" key={i}>
          <td className="sticky left-0 min-w-56 bg-card px-3 py-3 font-medium">{c.goal}</td>
          <td className="px-3">{c.kpi}</td>
          <td className="px-3">{c.method || "—"}</td>
          <td className="px-3">{c.unit}</td>
          <td className="px-3">{Math.round(c.weight * 100)}%</td>
          <td className="px-3">{c.target.t}</td>
          <td className="px-3">{c.target.b}</td>
          <td className="px-3">{c.target.s}</td>
          <td className="whitespace-nowrap px-3">{date(c.startDate)}</td>
          <td className="whitespace-nowrap px-3">{date(c.endDate)}</td>
          {!assignment && (
            <>
              <td className="px-3">
                {canResult ? (
                  <textarea
                    aria-label={`Kết quả thực hiện mục tiêu ${i + 1}`}
                    className="my-2 min-h-16 min-w-48 rounded-md border p-2"
                    value={c.result}
                    onChange={(e) => update(i, { result: e.target.value })}
                  />
                ) : (
                  c.result
                )}
              </td>
              <td className="px-3">
                {canSelf ? (
                  <select
                    aria-label={`Tự đánh giá mục tiêu ${i + 1}`}
                    className={fieldClass}
                    value={c.self}
                    onChange={(e) => update(i, { self: Number(e.target.value) })}
                  >
                    <option value={0}>—</option>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <option key={n}>{n}</option>
                    ))}
                  </select>
                ) : (
                  c.self || "—"
                )}
              </td>
              <td
                className="px-3 font-medium text-primary"
                aria-label={`Điểm phân bổ mục tiêu ${i + 1}`}
              >
                {c.council?.toFixed(4) ?? "—"}
              </td>
            </>
          )}
        </tr>
      ))}
    </>
  );
}
