import { test } from "node:test";
import assert from "node:assert/strict";
import {
  EVALUATIONS,
  transition,
  saveDraft,
  templateResult,
  kiError,
  mainStage,
  MAIN_STEPS,
  STEPS,
} from "../lib/evaluation.ts";

const source = () => structuredClone(EVALUATIONS[3]);
const move = (e, role, action, patch = {}) => transition(e, role, action, patch, "now");

test("self sends directly to office; office returns with reason and receives resubmission", () => {
  let e = move(source(), "performer", "submit");
  assert.equal(e.step, "office");
  assert.throws(() => move(e, "office", "return"), /lý do/);
  e = move(e, "office", "return", { note: "Bổ sung kết quả" });
  assert.equal(e.step, "office_return");
  e = move(e, "performer", "submit");
  assert.equal(e.step, "office");
  assert.equal(e.history.length, 3);
});

test("CQTT preserves its score through a reservation, council inherits and overrides only total", () => {
  let e = move(move(source(), "performer", "submit"), "office", "send");
  e = saveDraft(e, "cqtt", { cqttKey: 1.4, cqttFunction: 2.7, note: "Đề nghị bổ sung" }, "now");
  e = move(e, "cqtt", "request");
  e = move(e, "performer", "respond", { response: "Bảo lưu", responseNote: "Có hồ sơ nghiệm thu" });
  assert.equal(e.step, "cqtt_report");
  e = move(e, "cqtt", "send");
  assert.equal(e.councilScore, 4.1);
  const before = structuredClone(e.criteria);
  e = saveDraft(e, "council", { councilScore: 4.7, ki: "A+" }, "now");
  assert.equal(templateResult(e).score, 4.7);
  assert.equal(e.cqttKey + e.cqttFunction, 4.1);
  assert.deepEqual(
    e.criteria.map(({ council, ...c }) => c),
    before.map(({ council, ...c }) => c),
  );
  assert.ok(Math.abs(e.criteria.reduce((sum, c) => sum + c.weight * c.council, 0) - 4.7) < 1e-10);
});

test("CEO correction, approval and delivery preserve council result", () => {
  let e = {
    ...source(),
    step: "council",
    cqttKey: 1,
    cqttFunction: 3,
    councilScore: 4,
    ki: "A",
    locationCompliance: "Tuân thủ",
    laborCompliance: "Tuân thủ",
  };
  e = move(e, "council", "submit");
  e = move(e, "ceo", "return", { note: "Kiểm tra lại" });
  assert.equal(e.step, "council_adjust");
  e = saveDraft(e, "council", { councilScore: 4.4 }, "now");
  e = move(e, "council", "submit");
  e = move(e, "ceo", "approve");
  assert.equal(e.approvedScore, 4.4);
  assert.throws(() => saveDraft(e, "council", { councilScore: 5 }, "now"));
  e = move(e, "council", "send");
  e = move(e, "office", "send");
  e = move(e, "performer", "sign");
  assert.equal(e.step, "done");
  assert.equal(templateResult(e).score, 4.4);
});

test("wrong roles, incomplete self scores and invalid council scores are rejected", () => {
  assert.throws(() => move(source(), "council", "submit"));
  assert.throws(() =>
    move(
      { ...source(), criteria: source().criteria.map((c) => ({ ...c, self: 0 })) },
      "performer",
      "submit",
    ),
  );
  const e = { ...source(), step: "council", councilScore: 4, ki: "A" };
  for (const score of [NaN, -1, 5.1])
    assert.throws(() => saveDraft(e, "council", { councilScore: score }, "now"));
  assert.throws(() => saveDraft(e, "performer", { councilScore: 5 }, "now"));
  assert.ok(kiError({ ...e, locationCompliance: "Không tuân thủ" }));
});

test("history retains weighted CQTT group scores even when total is unchanged", () => {
  const e = { ...source(), step: "cqtt", cqttKey: 1.5, cqttFunction: 2.6 };
  const next = saveDraft(e, "cqtt", { cqttKey: 1.6, cqttFunction: 2.5 }, "now");
  const entry = next.history.at(-1);
  assert.equal(JSON.parse(entry.before).cqttKey, 1.5);
  assert.equal(JSON.parse(entry.after).cqttKey, 1.6);
  assert.equal(JSON.parse(entry.before).cqttFunction, 2.6);
  assert.equal(JSON.parse(entry.after).cqttFunction, 2.5);
});

test("main stages group every branch without losing records", () => {
  assert.equal(MAIN_STEPS.length, 6);
  assert.equal(mainStage("office_return"), "office");
  assert.equal(mainStage("response"), "cqtt");
  assert.equal(mainStage("cqtt_report"), "cqtt");
  assert.equal(mainStage("council_adjust"), "council");
  for (const key of ["approved", "dispatch", "sign", "done"])
    assert.equal(mainStage(key), "approved");
  for (const { key } of STEPS) assert.ok(MAIN_STEPS.some((s) => s.key === mainStage(key)));
});
