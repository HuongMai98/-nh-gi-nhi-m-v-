import { describe, expect, it } from "vitest";
import { ASSIGNING_UNIT, EVALUATIONS, canSelfEvaluate, mockPerformerFor, managerEvaluationTotal, rating, totalScore, type Criterion } from "@/lib/evaluation";

const c = (weight: number, self: number, manager: number) => ({ weight, self, manager }) as Criterion;

describe("evaluation scoring", () => {
  it("previews the performer for pending self-evaluation", () => {
    const pending = EVALUATIONS[3];
    if (!pending) throw new Error("Missing fixture");
    expect(pending.step).toBe("self");
    expect(mockPerformerFor(pending)).toBe("Nguyễn Thu Hà");
    expect(canSelfEvaluate(pending, mockPerformerFor(pending))).toBe(true);
  });
  it("keeps manager evaluation empty during pending self-evaluation", () => {
    const pending = EVALUATIONS[3];
    if (!pending) throw new Error("Missing fixture");
    expect(pending.criteria.every((item) => item.manager === undefined)).toBe(true);
    expect(managerEvaluationTotal(pending)).toBeNull();
    expect(managerEvaluationTotal(pending, pending.criteria.map((item) => ({ ...item, manager: 5 })))).toBeNull();
  });
  it("provides start and completion dates for every sample task", () => {
    expect(EVALUATIONS).toHaveLength(8);
    for (const evaluation of EVALUATIONS) {
      expect(evaluation.criteria).toHaveLength(9);
      for (const criterion of evaluation.criteria) {
        expect(criterion.startDate).toMatch(/^2026-07-\d{2}$/);
        expect(criterion.endDate).toMatch(/^2026-09-\d{2}$/);
        expect(Date.parse(criterion.endDate ?? "")).toBeGreaterThan(Date.parse(criterion.startDate ?? ""));
      }
    }
    expect(EVALUATIONS[0]?.criteria[0]).toMatchObject({ startDate: "2026-07-01", endDate: "2026-09-20" });
  });
  it("assigns work from Tập đoàn Công nghệ - Viễn thông Quân đội", () => {
    expect(ASSIGNING_UNIT).toEqual({ name: "Tập đoàn Công nghệ - Viễn thông Quân đội", label: "Tập đoàn" });
  });
  it("allows the work performer to evaluate their own work only", () => {
    const evaluation = EVALUATIONS[0];
    if (!evaluation) throw new Error("Missing evaluation fixture");
    expect(canSelfEvaluate(evaluation, "Đinh Ngọc Tuấn")).toBe(true);
    expect(canSelfEvaluate(evaluation, "Nguyễn Thu Hà")).toBe(false);
  });
  it("total = Σ weight × score (Excel sample 4.65)", () => {
    const rows = [c(0.15, 5, 5), c(0.15, 5, 4), c(0.1, 4, 5), c(0.1, 4, 5), c(0.1, 3, 5), c(0.1, 3, 5), c(0.1, 4, 5), c(0.1, 3, 4), c(0.1, 4, 4)];
    expect(totalScore(rows, "manager")).toBe(4.65);
    expect(totalScore(rows, "self")).toBe(4);
  });
  it("4.65 is rated Vượt xa yêu cầu", () => {
    expect(rating(4.65).label).toBe("Vượt xa yêu cầu");
  });
});
