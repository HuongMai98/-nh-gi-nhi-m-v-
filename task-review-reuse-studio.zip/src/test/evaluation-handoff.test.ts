import { describe, expect, it } from "vitest";
import { EVALUATIONS, scoresComplete, submitToManager, saveManagerScores } from "@/lib/evaluation";

const pending = EVALUATIONS[3];
if (!pending) throw new Error("Missing pending fixture");

describe("self to manager handoff", () => {
  it("notifies QLTT and leaves manager scores empty after self submission", () => {
    const submitted = submitToManager(pending, pending.criteria, "31/10/2026 18:10");
    expect(submitted.step).toBe("manager");
    expect(submitted.selfSubmittedAt).toBe("31/10/2026 18:10");
    expect(submitted.notificationRead).toBe(false);
    expect(submitted.criteria.every((item) => item.manager === undefined)).toBe(true);
    expect(submitted.criteria.map((item) => item.self)).toEqual(pending.criteria.map((item) => item.self));
    expect(submitToManager(submitted, submitted.criteria, "duplicate")).toBe(submitted);
  });
  it("requires all self scores between 1 and 5 before sending", () => {
    for (const self of [0, 6, 2.5]) {
      const invalid = pending.criteria.map((item, i) => i === 0 ? { ...item, self } : item);
      expect(submitToManager(pending, invalid, "now")).toBe(pending);
    }
  });
  it("saves manager scores without changing self scores or task dates", () => {
    const submitted = submitToManager(pending, pending.criteria, "sent");
    const saved = saveManagerScores(submitted, submitted.criteria.map((item) => ({ ...item, self: 1, startDate: "wrong", manager: 4 })), "saved");
    expect(saved.step).toBe("manager");
    expect(saved.criteria.map((item) => item.manager)).toEqual(Array(9).fill(4));
    expect(saved.criteria.map((item) => item.self)).toEqual(pending.criteria.map((item) => item.self));
    expect(saved.criteria.map((item) => item.startDate)).toEqual(pending.criteria.map((item) => item.startDate));
  });
  it("requires complete manager scoring before aggregation", () => {
    const submitted = submitToManager(pending, pending.criteria, "sent");
    expect(saveManagerScores(submitted, submitted.criteria, "now", true)).toBe(submitted);
    const scores = submitted.criteria.map((item) => ({ ...item, manager: 5 }));
    expect(scoresComplete(scores, "manager")).toBe(true);
    const completed = saveManagerScores(submitted, scores, "completed", true);
    expect(completed.step).toBe("office");
    expect(completed.managerCompletedAt).toBe("completed");
  });
});