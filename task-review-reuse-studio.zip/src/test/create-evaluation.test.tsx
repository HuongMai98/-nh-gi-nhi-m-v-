import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { EvaluationProvider } from "@/components/EvaluationProvider";
import { CreateEvaluationDialog } from "@/components/CreateEvaluationDialog";

describe("create evaluation", () => {
  it("creates a self-evaluation with the entered unit, deadline and criteria", () => {
    const onCreated = vi.fn();
    render(<EvaluationProvider><CreateEvaluationDialog open onOpenChange={() => {}} onCreated={onCreated} /></EvaluationProvider>);
    fireEvent.change(screen.getByPlaceholderText("Nhập tên đơn vị thực hiện"), { target: { value: "Ban Kiểm thử" } });
    fireEvent.change(screen.getByPlaceholderText("Nhập họ và tên"), { target: { value: "Nguyễn Minh Anh" } });
    fireEvent.change(screen.getByLabelText(/Hạn đánh giá/), { target: { value: "2026-11-20" } });
    fireEvent.change(screen.getByPlaceholderText("Nhập mục tiêu nhiệm vụ"), { target: { value: "Hoàn thành báo cáo" } });
    fireEvent.change(screen.getByPlaceholderText("Nhập chỉ số đo lường"), { target: { value: "Số báo cáo" } });
    fireEvent.change(screen.getByLabelText(/Tỷ trọng/), { target: { value: "80" } });
    fireEvent.click(screen.getByRole("button", { name: /^Tạo đánh giá$/ }));
    expect(onCreated).not.toHaveBeenCalled();
    fireEvent.change(screen.getByLabelText(/Tỷ trọng/), { target: { value: "100" } });
    fireEvent.click(screen.getByRole("button", { name: /^Tạo đánh giá$/ }));
    expect(onCreated).toHaveBeenCalledWith(expect.objectContaining({
      unit: "Ban Kiểm thử", owner: "Nguyễn Minh Anh", deadline: "20/11/2026", period: "Quý III/2026", step: "self",
      criteria: [expect.objectContaining({ goal: "Hoàn thành báo cáo", kpi: "Số báo cáo", weight: 1, self: 0 })],
    }));
  });
});