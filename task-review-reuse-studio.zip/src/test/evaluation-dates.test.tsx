import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { EvaluationProvider } from "@/components/EvaluationProvider";
import { useEvaluations } from "@/components/evaluation-context";
import { EVALUATIONS } from "@/lib/evaluation";

function DateSaveProbe() {
  const { evaluations, addEvaluation, saveCriteriaDetails, saveSelfEvaluation } = useEvaluations();
  const source = EVALUATIONS[0];
  if (!source) throw new Error("Missing fixture");
  const evaluation = evaluations.find((item) => item.id === "task-date-test");
  return <>
    <button onClick={() => addEvaluation({ ...source, id: "task-date-test", criteria: source.criteria.map((item) => ({ ...item, startDate: "2026-10-01", endDate: "2026-10-31" })) })}>Load task</button>
    <button onClick={() => {
      if (!evaluation) return;
      const changed = evaluation.criteria.map((item) => ({ ...item, startDate: "2027-01-01", endDate: "2027-02-01", kpi: "Báo cáo", method: "Đếm", unit: "Bản", result: "10", self: 4 }));
      saveCriteriaDetails(evaluation.id, changed);
      saveSelfEvaluation(evaluation.id, changed);
    }}>Save evaluation</button>
    <output data-testid="saved-criteria">{JSON.stringify(evaluation?.criteria[0])}</output>
  </>;
}

describe("task-owned evaluation dates", () => {
  it("preserves both task dates while saving descriptions and self scores", () => {
    render(<EvaluationProvider><DateSaveProbe /></EvaluationProvider>);
    fireEvent.click(screen.getByText("Load task"));
    fireEvent.click(screen.getByText("Save evaluation"));
    const saved = JSON.parse(screen.getByTestId("saved-criteria").textContent ?? "{}");
    expect(saved.startDate).toBe("2026-10-01");
    expect(saved.endDate).toBe("2026-10-31");
    expect(saved).toMatchObject({ kpi: "Báo cáo", method: "Đếm", unit: "Bản", result: "10", self: 4 });
  });
});