import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Download, MessageSquare, Save, Send, Undo2 } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { STATUS, STEPS, canSelfEvaluate, mockPerformerFor, managerEvaluationTotal, scoresComplete, getEvaluation, rating, totalScore, type Criterion } from "@/lib/evaluation";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useEvaluations } from "@/components/evaluation-context";
import type { Evaluation } from "@/lib/evaluation";

export const Route = createFileRoute("/danh-gia/$id")({
  loader: ({ params }) => {
    const e = getEvaluation(params.id);
    return e ?? null;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.id} – Phiếu đánh giá` : "Phiếu đánh giá" },
      { name: "description", content: "Phiếu đánh giá kết quả thực hiện nhiệm vụ, chấm điểm theo luồng CQĐV → CQTT → Hội đồng → TGĐ." },
      { property: "og:title", content: "Phiếu đánh giá nhiệm vụ" },
      { property: "og:description", content: "Chấm điểm và phê duyệt kết quả thực hiện nhiệm vụ." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Detail,
});

const GROUPS: [Criterion["group"], string][] = [
  ["A", "A. Nhóm mục tiêu theo nhiệm vụ trọng tâm"],
  ["B-I", "B.I. Mục tiêu theo chức năng"],
  ["B-II", "B.II. Chỉ số kiểm soát ngành dọc"],
];

function Detail() {
  const { evaluations, previewRole } = useEvaluations();
  const { id } = Route.useParams();
  const ev = evaluations.find((evaluation) => evaluation.id === id) ?? Route.useLoaderData();
  if (!ev) throw notFound();
  return <EvaluationDetail key={`${ev.id}-${ev.step}-${previewRole}`} ev={ev} />;
}

function EvaluationDetail({ ev }: { ev: Evaluation }) {
  const { saveSelfEvaluation, saveCriteriaDetails, previewRole, submitSelfEvaluation, saveManagerEvaluation } = useEvaluations();
  const canSelf = previewRole === "performer" && !ev.selfSubmittedAt && canSelfEvaluate(ev, mockPerformerFor(ev));
  const canManager = previewRole === "manager" && ev.step === "manager";
  const [saved, setSaved] = useState("");
  const [error, setError] = useState("");
  const [items, setItems] = useState<Criterion[]>(ev.criteria.map((c) => ({ ...c, manager: ev.step === "self" ? undefined : c.manager })));
  const stepIdx = STEPS.findIndex((s) => s.key === ev.step);
  const selfT = totalScore(items, "self");
  const mgrT = managerEvaluationTotal(ev, items);
  const r = mgrT === null ? null : rating(mgrT);
  const setScore = (i: number, v: number) => setItems((s) => s.map((c, j) => (j === i ? { ...c, manager: v } : c)));
  const setSelfScore = (i: number, v: number) => { setSaved(""); setItems((s) => s.map((c, j) => j === i ? { ...c, self: v } : c)); };
  const setField = (i: number, f: Field, v: string) => { setSaved(""); setItems((s) => s.map((c, j) => j === i ? { ...c, [f]: v } : c)); };

  return (
    <AppShell
      crumbs={<><Link to="/" className="hover:text-foreground">Đánh giá</Link><span>›</span><span>{ev.id}</span></>}
      title={`Phiếu đánh giá – ${ev.unit}`}
      actions={<>
        <Button variant="outline" onClick={() => { saveCriteriaDetails(ev.id, items); setSaved("Đã lưu thông tin phiếu"); }}><Save />Lưu thông tin</Button>
        {canSelf && <Button onClick={() => { saveCriteriaDetails(ev.id, items); saveSelfEvaluation(ev.id, items); setSaved("Đã lưu tự đánh giá"); }}><Save />Lưu tự đánh giá</Button>}
        {canSelf && ev.step === "self" && <Button onClick={() => {
          if (!scoresComplete(items, "self")) { setError("Vui lòng chọn điểm tự đánh giá từ 1–5 cho tất cả mục tiêu."); return; }
          saveCriteriaDetails(ev.id, items); submitSelfEvaluation(ev.id, items);
        }}><Send />Gửi QLTT đánh giá</Button>}
        {canManager && <><Button variant="outline" onClick={() => { saveManagerEvaluation(ev.id, items); setSaved("Đã lưu điểm QLTT"); }}><Save />Lưu điểm QLTT</Button><Button onClick={() => {
          if (!scoresComplete(items, "manager")) { setError("Vui lòng chọn điểm QLTT từ 1–5 cho tất cả mục tiêu."); return; }
          saveManagerEvaluation(ev.id, items, true);
        }}><Check />Hoàn tất đánh giá QLTT</Button></>}
        <button className="flex items-center gap-1.5 rounded-lg border px-3 py-2.5 text-sm"><Download className="h-4 w-4" />Xuất phiếu</button>
        <button className="flex items-center gap-1.5 rounded-lg border border-primary px-3 py-2.5 text-sm text-primary"><Undo2 className="h-4 w-4" />Yêu cầu điều chỉnh</button>
        {!["self", "manager"].includes(ev.step) && <button className="flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"><Send className="h-4 w-4" />Chuyển bước tiếp</button>}
      </>}
    >
      {saved && <p role="status" className="mb-4 text-sm text-success">{saved}</p>}
      {error && <p role="alert" className="mb-4 text-sm text-primary">{error}</p>}
      {ev.step === "manager" && <p role="status" className="mb-4 border-l-2 border-info bg-info-soft px-4 py-3 text-sm text-info">{ev.owner} đã gửi tự đánh giá lúc {ev.selfSubmittedAt}. Chờ QLTT đánh giá.</p>}
      {ev.managerCompletedAt && <p role="status" className="mb-4 text-sm text-success">QLTT đã hoàn tất đánh giá lúc {ev.managerCompletedAt}.</p>}
      <ol className="mb-5 flex overflow-x-auto rounded-lg border p-4">
        {STEPS.map((s, i) => (
          <li key={s.key} className="flex min-w-36 flex-1 items-center gap-3">
            <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-sm font-semibold",
              i < stepIdx && "border-success bg-success text-primary-foreground",
              i === stepIdx && "border-primary bg-primary text-primary-foreground",
              i > stepIdx && "text-muted-foreground")}>{i < stepIdx ? <Check className="h-4 w-4" /> : i + 1}</span>
            <div className="text-xs leading-tight">
              <div className={cn("font-medium", i === stepIdx && "text-primary")}>{s.label}</div>
              <div className="text-muted-foreground">{s.key === "office" && ev.block === "Khối Đơn vị" ? "Ban Chiến lược" : s.key === "office" ? "Văn phòng" : s.actor}</div>
            </div>
            {i < STEPS.length - 1 && <div className={cn("mx-3 h-px flex-1", i < stepIdx ? "bg-success" : "bg-border")} />}
          </li>
        ))}
      </ol>

      <div className="grid grid-cols-[1fr_300px] gap-5">
        <div className="min-w-0">
          <div className="mb-4 grid grid-cols-4 gap-4 rounded-lg bg-muted/60 p-4 text-sm">
            {[["Kỳ đánh giá", ev.period], ["Khối", ev.block], ["Người thực hiện", ev.owner], ["Trạng thái", <StatusPill key="s" tone={STATUS[ev.step].tone}>{STATUS[ev.step].label}</StatusPill>]].map(([k, v], i) => (
              <div key={i}><div className="text-xs text-muted-foreground">{k}</div><div className="mt-1 font-medium">{v}</div></div>
            ))}
          </div>

          <div className="overflow-x-auto rounded-lg border">
            <table className="w-full min-w-[1700px] text-sm">
              <thead className="bg-muted text-xs">
                <tr>
                  <th rowSpan={2} className="px-2 py-2 text-left font-medium">Mục tiêu nhiệm vụ/công việc</th>
                  <th rowSpan={2} className="px-2 text-left font-medium">Chỉ số đo lường KPI</th>
                  <th rowSpan={2} className="px-2 text-left font-medium">Phương pháp đo</th>
                  <th rowSpan={2} className="px-2 text-left font-medium">Đơn vị đo</th>
                  <th rowSpan={2} className="px-2 font-medium">Tỷ trọng</th>
                  <th colSpan={3} className="border-b px-2 py-1.5 font-medium">Các mức chỉ tiêu</th>
                  <th rowSpan={2} className="px-2 font-medium">Ngày bắt đầu</th>
                  <th rowSpan={2} className="px-2 font-medium">Ngày hoàn thành</th>
                  <th rowSpan={2} className="px-2 text-left font-medium">Kết quả thực hiện</th>
                  <th rowSpan={2} className="px-2 font-medium">CBNV tự ĐG</th>
                  <th rowSpan={2} className="px-2 font-medium text-primary">QLTT đánh giá (1–5)</th>
                </tr>
                <tr>{["T", "B", "S"].map((h) => <th key={h} className="px-2 py-1.5 font-medium text-muted-foreground">{h}</th>)}</tr>
              </thead>
              <tbody>
                {GROUPS.map(([g, label]) => (
                  <Group key={g} label={label} rows={items.map((c, i) => [c, i] as const).filter(([c]) => c.group === g)} setScore={canManager ? setScore : undefined} setSelfScore={canSelf ? setSelfScore : undefined} setField={setField} />
                ))}
                <tr className="bg-muted/60 font-semibold">
                  <td colSpan={4} className="px-2 py-3">Tổng điểm (Σ Tỷ trọng × Điểm)</td>
                  <td className="text-center">{Math.round(items.reduce((a, c) => a + c.weight, 0) * 100)}%</td>
                  <td colSpan={6} />
                  <td className="text-center">{selfT.toFixed(2)}</td>
                  <td className="text-center text-primary">{mgrT?.toFixed(2) ?? ""}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <aside className="space-y-4">
          <div className="rounded-lg border p-4 text-center">
            <div className="text-xs text-muted-foreground">Xếp loại dự kiến</div>
            <div className="mt-1 text-5xl font-bold text-primary">{r?.ki ?? "—"}</div>
            <div className="mt-1 text-sm font-medium">{r?.label ?? "Chưa có đánh giá"}</div>
            <div className="mt-3 flex justify-around border-t pt-3 text-sm">
              <div><div className="text-xs text-muted-foreground">Tự ĐG</div><div className="font-semibold">{selfT.toFixed(2)}</div></div>
              <div><div className="text-xs text-muted-foreground">QLTT</div><div className="min-h-5 font-semibold">{mgrT?.toFixed(2) ?? ""}</div></div>
            </div>
          </div>
          <div className="rounded-lg border p-4 text-sm">
            <div className="mb-3 font-medium">Đánh giá tuân thủ</div>
            {["Địa điểm làm việc", "Nội quy lao động", "Văn hoá Viettel"].map((t) => (
              <label key={t} className="mb-2 flex items-center justify-between">{t}<select className="rounded border px-2 py-1 text-xs"><option>Tuân thủ</option><option>Vi phạm</option></select></label>
            ))}
          </div>
          <div className="rounded-lg border p-4 text-sm">
            <div className="mb-2 flex items-center gap-2 font-medium"><MessageSquare className="h-4 w-4" />Ý kiến xử lý</div>
            <div className="mb-3 space-y-2 text-xs">
              <div className="rounded bg-muted p-2"><b>Văn phòng</b> · 20/10: Đã tổng hợp, chuyển CQTT.</div>
              <div className="rounded bg-muted p-2"><b>CQĐV</b> · 18/10: Gửi kết quả tự đánh giá.</div>
            </div>
            <textarea rows={3} placeholder="Nhập nhận xét..." className="w-full rounded-md border p-2 text-sm outline-none focus:border-primary" />
          </div>
        </aside>
      </div>
    </AppShell>
  );
}

type Field = "kpi" | "method" | "unit" | "result";
const cell = "h-8 w-full rounded-md border border-input bg-card px-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring";

function Group({ label, rows, setScore, setSelfScore, setField }: { label: string; rows: (readonly [Criterion, number])[]; setScore: ((i: number, v: number) => void) | undefined; setSelfScore?: ((i: number, v: number) => void) | undefined; setField: (i: number, f: Field, v: string) => void }) {
  const text = (c: Criterion, i: number, f: Field, name: string, w: string, ph = "") => (
    <td className="px-1 py-2"><input aria-label={`${name} mục tiêu ${i + 1}`} value={c[f] ?? ""} placeholder={ph} onChange={(e) => setField(i, f, e.target.value)} className={cn(cell, w)} /></td>
  );
  const date = (value: string | undefined) => (
    <td className="whitespace-nowrap px-2 py-2 text-center">{value ? <time dateTime={value}>{/^\d{4}-\d{2}-\d{2}$/.test(value) ? value.split("-").reverse().join("/") : value}</time> : "—"}</td>
  );
  return (
    <>
      <tr className="bg-accent/50"><td colSpan={14} className="px-2 py-2 text-xs font-semibold text-accent-foreground">{label}</td></tr>
      {rows.map(([c, i]) => (
        <tr key={i} className="border-t align-middle">
          <td className="min-w-[220px] px-2 py-3 font-medium">{c.goal}</td>
          {text(c, i, "kpi", "Chỉ số đo lường KPI", "min-w-[180px]")}
          {text(c, i, "method", "Phương pháp đo", "min-w-[180px]", "Công thức / cách tính")}
          {text(c, i, "unit", "Đơn vị đo", "w-24", "%, số lượng…")}
          <td className="text-center">{Math.round(c.weight * 100)}%</td>
          <td className="text-center text-muted-foreground">{c.target.t}</td>
          <td className="text-center text-muted-foreground">{c.target.b}</td>
          <td className="text-center text-muted-foreground">{c.target.s}</td>
          {date(c.startDate)}
          {date(c.endDate)}
          {text(c, i, "result", "Kết quả thực hiện", "min-w-[180px]", "Nhập kết quả")}
          <td className="px-2 text-center">{setSelfScore ? <select aria-label={`Tự đánh giá mục tiêu ${i + 1}`} value={c.self} onChange={(event) => setSelfScore(i, Number(event.target.value))} className="h-8 rounded-md border border-input bg-card px-2 text-sm"><option value={0}>—</option>{[1, 2, 3, 4, 5].map((score) => <option key={score} value={score}>{score}</option>)}</select> : c.self}</td>
          <td className="px-2 text-center">
            {setScore ? <select aria-label={`QLTT đánh giá mục tiêu ${i + 1}`} value={c.manager ?? ""} onChange={(event) => { if (event.target.value) setScore(i, Number(event.target.value)); }} className="h-8 rounded-md border border-input bg-card px-2 text-sm"><option value="">—</option>{[1, 2, 3, 4, 5].map((score) => <option key={score} value={score}>{score}</option>)}</select> : c.manager ?? ""}
          </td>
        </tr>
      ))}
    </>
  );
}
