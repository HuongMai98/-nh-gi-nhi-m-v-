export type Step = "self" | "manager" | "office" | "cqtt" | "council" | "ceo" | "done";
export type PreviewRole = "performer" | "manager";

export const ASSIGNING_UNIT = { name: "Tập đoàn Công nghệ - Viễn thông Quân đội", label: "Tập đoàn" };
export const MOCK_CURRENT_PERFORMER = "Đinh Ngọc Tuấn";

/** Preview the performer's role on pending self-evaluations; not real authentication. */
export const mockPerformerFor = (evaluation: Evaluation) => evaluation.step === "self" ? evaluation.owner : MOCK_CURRENT_PERFORMER;

export function managerEvaluationTotal(evaluation: Evaluation, criteria = evaluation.criteria) {
  return evaluation.step === "self" || !criteria.some((item) => item.manager !== undefined) ? null : totalScore(criteria, "manager");
}

/** Mockup availability only; not authentication or server authorization. */
export function canSelfEvaluate(evaluation: Evaluation, performer: string) {
  return evaluation.owner === performer;
}

export const STEPS: { key: Step; label: string; actor: string }[] = [
  { key: "self", label: "Tự đánh giá", actor: "Người thực hiện" },
  { key: "manager", label: "QLTT đánh giá", actor: "Quản lý trực tiếp" },
  { key: "office", label: "Tổng hợp KQ", actor: "Văn phòng / Ban CL" },
  { key: "cqtt", label: "Rà soát, chấm điểm", actor: "CQTT" },
  { key: "council", label: "Chấm điểm, tính Ki", actor: "Hội đồng" },
  { key: "ceo", label: "Phê duyệt kết quả", actor: "TGĐ" },
  { key: "done", label: "Trình ký phiếu ĐG", actor: "CQĐV" },
];

export const STATUS: Record<Step, { label: string; tone: "warning" | "info" | "danger" | "success" | "muted" }> = {
  self: { label: "Chờ tự đánh giá", tone: "warning" },
  manager: { label: "Chờ QLTT đánh giá", tone: "warning" },
  office: { label: "Đang tổng hợp", tone: "info" },
  cqtt: { label: "CQTT đang rà soát", tone: "info" },
  council: { label: "Hội đồng chấm điểm", tone: "info" },
  ceo: { label: "Chờ TGĐ phê duyệt", tone: "danger" },
  done: { label: "Đã phê duyệt", tone: "success" },
};

export type Criterion = {
  group: "A" | "B-I" | "B-II";
  goal: string;
  kpi: string;
  unit: string;
  method?: string | undefined;
  startDate?: string | undefined;
  endDate?: string | undefined;
  weight: number;
  target: { t: string; b: string; s: string };
  result: string;
  self: number;
  manager?: number | undefined;
  note?: string;
};

export type Evaluation = {
  id: string;
  unit: string;
  block: "Khối Cơ quan" | "Khối Đơn vị";
  period: string;
  owner: string;
  step: Step;
  deadline: string;
  updated: string;
  selfSubmittedAt?: string;
  managerCompletedAt?: string;
  notificationRead?: boolean;
  criteria: Criterion[];
};

export const scoresComplete = (criteria: Criterion[], who: "self" | "manager") => criteria.length > 0 && criteria.every((item) => {
  const score = item[who];
  return score !== undefined && Number.isInteger(score) && score >= 1 && score <= 5;
});

/** In-memory mockup handoff; no external notification or authorization. */
export function submitToManager(evaluation: Evaluation, criteria: Criterion[], timestamp: string): Evaluation {
  if (evaluation.step !== "self" || !scoresComplete(criteria, "self") || criteria.length !== evaluation.criteria.length) return evaluation;
  return { ...evaluation, step: "manager", updated: timestamp, selfSubmittedAt: timestamp, notificationRead: false,
    criteria: evaluation.criteria.map((item, i) => ({ ...item, self: criteria[i]?.self ?? item.self, manager: undefined })) };
}

export function saveManagerScores(evaluation: Evaluation, criteria: Criterion[], timestamp: string, complete = false): Evaluation {
  if (evaluation.step !== "manager" || criteria.length !== evaluation.criteria.length || (complete && !scoresComplete(criteria, "manager"))) return evaluation;
  const valid = criteria.every((item) => item.manager === undefined || (Number.isInteger(item.manager) && item.manager >= 1 && item.manager <= 5));
  if (!valid) return evaluation;
  return { ...evaluation, updated: timestamp, ...(complete ? { step: "office" as const, managerCompletedAt: timestamp } : {}),
    criteria: evaluation.criteria.map((item, i) => ({ ...item, manager: criteria[i]?.manager })) };
}

/** Σ weight × score, rounded to 2 decimals. */
export function totalScore(items: Criterion[], who: "self" | "manager") {
  const sum = items.reduce((acc, c) => acc + c.weight * ((who === "self" ? c.self : c.manager) ?? 0), 0);
  return Math.round(sum * 100) / 100;
}

/** Mapping score → rating (giả định, cần xác nhận theo quy chế). */
export function rating(score: number) {
  if (score >= 4.5) return { ki: "A+", label: "Vượt xa yêu cầu" };
  if (score >= 3.5) return { ki: "A", label: "Vượt yêu cầu" };
  if (score >= 2.5) return { ki: "B", label: "Đạt yêu cầu" };
  if (score >= 1.5) return { ki: "C", label: "Cần cải thiện" };
  return { ki: "D", label: "Không đạt yêu cầu" };
}

const base: Criterion[] = [
  { group: "A", goal: "Triển khai nền tảng vOffice cho 5 đơn vị thành viên", kpi: "Số đơn vị go-live", unit: "Đơn vị", weight: 0.15, target: { t: "3", b: "5", s: "6" }, result: "6 đơn vị", self: 5, manager: 5 },
  { group: "A", goal: "Chuyển đổi số quy trình giao nhiệm vụ", kpi: "% quy trình số hoá", unit: "%", weight: 0.15, target: { t: "70", b: "85", s: "95" }, result: "88%", self: 5, manager: 4 },
  { group: "A", goal: "Báo cáo chiến lược quý đúng hạn", kpi: "Số báo cáo trễ hạn", unit: "Báo cáo", weight: 0.1, target: { t: "2", b: "0", s: "0" }, result: "0", self: 4, manager: 5 },
  { group: "B-I", goal: "Đảm bảo SLA hỗ trợ người dùng", kpi: "Tỷ lệ ticket đúng SLA", unit: "%", weight: 0.1, target: { t: "90", b: "95", s: "98" }, result: "96,4%", self: 4, manager: 5 },
  { group: "B-I", goal: "Tối ưu chi phí vận hành", kpi: "Chi phí giảm so với KH", unit: "%", weight: 0.1, target: { t: "3", b: "5", s: "8" }, result: "4,1%", self: 3, manager: 5 },
  { group: "B-I", goal: "Đào tạo nội bộ", kpi: "Giờ đào tạo / CBNV", unit: "Giờ", weight: 0.1, target: { t: "16", b: "24", s: "32" }, result: "22", self: 3, manager: 5 },
  { group: "B-II", goal: "Tuân thủ an toàn thông tin", kpi: "Số sự cố ATTT", unit: "Sự cố", weight: 0.1, target: { t: "1", b: "0", s: "0" }, result: "0", self: 4, manager: 5 },
  { group: "B-II", goal: "Kiểm soát tài chính", kpi: "Sai lệch quyết toán", unit: "%", weight: 0.1, target: { t: "2", b: "1", s: "0,5" }, result: "0,9%", self: 3, manager: 4 },
  { group: "B-II", goal: "Kiểm soát pháp chế", kpi: "Văn bản bị trả lại", unit: "Văn bản", weight: 0.1, target: { t: "3", b: "1", s: "0" }, result: "1", self: 4, manager: 4 },
];

const units: [string, Evaluation["block"], Step, string][] = [
  ["Tổng công ty Giải pháp doanh nghiệp Viettel", "Khối Đơn vị", "ceo", "Đinh Ngọc Tuấn"],
  ["Ban Chiến lược Tập đoàn", "Khối Cơ quan", "council", "Phạm Hoàng Giang"],
  ["Trung tâm Công nghệ thông tin", "Khối Đơn vị", "cqtt", "Lê Minh Châu"],
  ["Văn phòng Tập đoàn", "Khối Cơ quan", "self", "Nguyễn Thu Hà"],
  ["Ban Tài chính", "Khối Cơ quan", "office", "Trần Quốc Bảo"],
  ["Tổng công ty Viễn thông Viettel", "Khối Đơn vị", "done", "Vũ Đức Anh"],
  ["Ban Tổ chức lao động", "Khối Cơ quan", "done", "Hoàng Lan Phương"],
  ["Tổng công ty Mạng lưới Viettel", "Khối Đơn vị", "cqtt", "Đỗ Văn Khoa"],
];

export const EVALUATIONS: Evaluation[] = units.map(([unit, block, step, owner], i) => ({
  id: `DG-2026-Q3-${String(i + 1).padStart(3, "0")}`,
  unit,
  block,
  period: "Quý III/2026",
  owner,
  step,
  deadline: `${String(10 + i).padStart(2, "0")}/11/2026`,
  updated: `${String(20 + (i % 9)).padStart(2, "0")}/10/2026 1${i % 6}:0${i}:12`,
  criteria: base.map((c, j) => ({
    ...c,
    // Sample task dates for the Q3 mockup, not live task-screen data.
    startDate: `2026-07-${String(1 + j * 2).padStart(2, "0")}`,
    endDate: `2026-09-${String(20 + j).padStart(2, "0")}`,
    self: Math.max(1, Math.min(5, c.self - ((i + j) % 3 === 0 ? 1 : 0))),
    manager: ["self", "office"].includes(step) ? undefined : c.manager,
  })),
}));

export const getEvaluation = (id: string) => EVALUATIONS.find((e) => e.id === id);
