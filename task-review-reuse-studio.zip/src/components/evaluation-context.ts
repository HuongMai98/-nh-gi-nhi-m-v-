import { createContext, useContext, type Context } from "react";
import type { Criterion, Evaluation, PreviewRole } from "@/lib/evaluation";

type EvaluationState = {
  evaluations: Evaluation[];
  addEvaluation: (evaluation: Evaluation) => void;
  saveSelfEvaluation: (id: string, criteria: Criterion[]) => void;
  saveCriteriaDetails: (id: string, criteria: Criterion[]) => void;
  previewRole: PreviewRole;
  setPreviewRole: (role: PreviewRole) => void;
  submitSelfEvaluation: (id: string, criteria: Criterion[]) => void;
  saveManagerEvaluation: (id: string, criteria: Criterion[], complete?: boolean) => void;
  openManagerNotification: (id: string) => void;
};

// Preserve identity even when this module itself is replaced during Vite HMR.
// The cache is module-local HMR data, never a global user-state store.
const previousContext = import.meta.hot?.data?.evaluationContext as Context<EvaluationState | null> | undefined;
export const EvaluationContext = previousContext ?? createContext<EvaluationState | null>(null);
if (import.meta.hot?.data) {
  import.meta.hot.data.evaluationContext = EvaluationContext;
}

export function useEvaluations() {
  const context = useContext(EvaluationContext);
  if (!context) throw new Error("EvaluationProvider is required");
  return context;
}