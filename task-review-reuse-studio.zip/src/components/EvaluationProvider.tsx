import { useState, type ReactNode } from "react";
import { EVALUATIONS, canSelfEvaluate, mockPerformerFor, submitToManager, saveManagerScores, type PreviewRole, type Criterion, type Evaluation } from "@/lib/evaluation";
import { EvaluationContext } from "@/components/evaluation-context";

export function EvaluationProvider({ children }: { children: ReactNode }) {
  const [evaluations, setEvaluations] = useState(EVALUATIONS);
  const [previewRole, setPreviewRole] = useState<PreviewRole>("performer");
  const now = () => new Date().toLocaleString("vi-VN");
  const saveSelfEvaluation = (id: string, criteria: Criterion[]) => setEvaluations((current) => current.map((evaluation) => evaluation.id === id && previewRole === "performer" && !evaluation.selfSubmittedAt && canSelfEvaluate(evaluation, mockPerformerFor(evaluation)) ? { ...evaluation, criteria: evaluation.criteria.map((criterion, i) => ({ ...criterion, self: criteria[i]?.self ?? criterion.self })), updated: now() } : evaluation));
   /** Saves evaluation descriptions; task-owned dates and gated scores remain unchanged. */
   const saveCriteriaDetails = (id: string, criteria: Criterion[]) => setEvaluations((current) => current.map((evaluation) => evaluation.id !== id ? evaluation : { ...evaluation, updated: now(), criteria: evaluation.criteria.map((criterion, i) => { const c = criteria[i]; return c ? { ...criterion, kpi: c.kpi, method: c.method, unit: c.unit, result: c.result } : criterion; }) }));
  const submitSelfEvaluation = (id: string, criteria: Criterion[]) => {
    if (previewRole !== "performer") return;
    setEvaluations((current) => current.map((evaluation) => evaluation.id === id && canSelfEvaluate(evaluation, mockPerformerFor(evaluation)) ? submitToManager(evaluation, criteria, now()) : evaluation));
  };
  const saveManagerEvaluation = (id: string, criteria: Criterion[], complete = false) => {
    if (previewRole !== "manager") return;
    setEvaluations((current) => current.map((evaluation) => evaluation.id === id ? saveManagerScores(evaluation, criteria, now(), complete) : evaluation));
  };
  const openManagerNotification = (id: string) => {
    if (previewRole !== "manager") return;
    setEvaluations((current) => current.map((evaluation) => evaluation.id === id ? { ...evaluation, notificationRead: true } : evaluation));
  };
  return <EvaluationContext.Provider value={{ evaluations, previewRole, setPreviewRole, submitSelfEvaluation, saveManagerEvaluation, openManagerNotification, addEvaluation: (evaluation) => setEvaluations((current) => [evaluation, ...current]), saveSelfEvaluation, saveCriteriaDetails }}>{children}</EvaluationContext.Provider>;
}

