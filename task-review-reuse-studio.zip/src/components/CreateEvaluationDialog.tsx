import { useState, type FormEvent } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useEvaluations } from "@/components/evaluation-context";
import type { Criterion, Evaluation } from "@/lib/evaluation";

const blankCriterion = (): Criterion => ({ group: "A", goal: "", kpi: "", unit: "", weight: 1, target: { t: "", b: "", s: "" }, result: "", self: 0 });
const selectClass = "h-9 w-full rounded-md border border-input bg-card px-3 text-sm focus:outline-none focus:ring-1 focus:ring-ring";

export function CreateEvaluationDialog({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (open: boolean) => void; onCreated: (evaluation: Evaluation) => void }) {
  const { evaluations, addEvaluation } = useEvaluations();
  const [unit, setUnit] = useState("");
  const [block, setBlock] = useState<Evaluation["block"]>("Khối Cơ quan");
  const [owner, setOwner] = useState("");
  const [quarter, setQuarter] = useState("III");
  const [year, setYear] = useState("2026");
  const [deadline, setDeadline] = useState("");
  const [criteria, setCriteria] = useState<Criterion[]>([blankCriterion()]);
  const [error, setError] = useState("");
  const weight = Math.round(criteria.reduce((sum, item) => sum + item.weight, 0) * 10000) / 100;
  const update = (index: number, changes: Partial<Criterion>) => setCriteria((current) => current.map((item, i) => i === index ? { ...item, ...changes } : item));

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!unit.trim() || !owner.trim() || criteria.some((item) => !item.goal.trim() || !item.kpi.trim())) {
      setError("Vui lòng nhập đầy đủ các trường bắt buộc.");
      return;
    }
    if (weight !== 100) { setError("Tổng tỷ trọng các mục tiêu phải bằng 100%."); return; }
    const [y, m, d] = deadline.split("-");
    const period = `Quý ${quarter}/${year}`;
    const prefix = `DG-${year}-Q${["I", "II", "III", "IV"].indexOf(quarter) + 1}-`;
    let sequence = 1;
    while (evaluations.some((item) => item.id === `${prefix}${String(sequence).padStart(3, "0")}`)) sequence += 1;
    const evaluation: Evaluation = {
      id: `${prefix}${String(sequence).padStart(3, "0")}`, unit: unit.trim(), block, owner: owner.trim(), period,
      deadline: `${d}/${m}/${y}`, updated: new Date().toLocaleString("vi-VN"), step: "self", criteria,
    };
    addEvaluation(evaluation);
    onCreated(evaluation);
    onOpenChange(false);
  }

  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="max-h-[90dvh] w-[calc(100%-2rem)] max-w-3xl overflow-y-auto bg-card p-0" aria-describedby={undefined}>
      <DialogHeader className="border-b px-6 py-5 pr-12"><DialogTitle className="tracking-normal">Tạo đánh giá nhiệm vụ</DialogTitle></DialogHeader>
      <form onSubmit={submit}>
        <div className="space-y-6 px-6 py-5">
          <section>
            <h2 className="mb-4 text-sm font-semibold">Thông tin đánh giá</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="space-y-2 text-sm">Đơn vị thực hiện <span className="text-primary">*</span><Input autoFocus required value={unit} onChange={(event) => setUnit(event.target.value)} placeholder="Nhập tên đơn vị thực hiện" /></label>
              <label className="space-y-2 text-sm">Khối <span className="text-primary">*</span><select className={selectClass} value={block} onChange={(event) => setBlock(event.target.value as Evaluation["block"])}><option>Khối Cơ quan</option><option>Khối Đơn vị</option></select></label>
              <label className="space-y-2 text-sm">Kỳ đánh giá <span className="text-primary">*</span><div className="flex gap-2"><select aria-label="Quý đánh giá" className={selectClass} value={quarter} onChange={(event) => setQuarter(event.target.value)}>{["I", "II", "III", "IV"].map((q) => <option key={q} value={q}>Quý {q}</option>)}</select><Input aria-label="Năm đánh giá" required type="number" min="2000" max="2100" value={year} onChange={(event) => setYear(event.target.value)} /></div></label>
              <label className="space-y-2 text-sm">Hạn đánh giá <span className="text-primary">*</span><Input required type="date" value={deadline} onChange={(event) => setDeadline(event.target.value)} /></label>
              <label className="space-y-2 text-sm sm:col-span-2">Người thực hiện <span className="text-primary">*</span><Input required value={owner} onChange={(event) => setOwner(event.target.value)} placeholder="Nhập họ và tên" /></label>
            </div>
          </section>
          <section className="border-t pt-5">
            <div className="mb-4 flex items-center justify-between gap-2"><h2 className="text-sm font-semibold">Mục tiêu / KPI</h2><span className={weight === 100 ? "text-sm text-success" : "text-sm text-primary"}>Tổng tỷ trọng: {weight}%</span></div>
            <div className="space-y-4">
              {criteria.map((item, index) => <div key={index} className="rounded-lg border p-4">
                <div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-medium">Mục tiêu {index + 1}</h3><Button type="button" variant="ghost" size="icon" title="Xóa mục tiêu" aria-label={`Xóa mục tiêu ${index + 1}`} disabled={criteria.length === 1} onClick={() => setCriteria((current) => current.filter((_, i) => i !== index))}><Trash2 /></Button></div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <label className="space-y-1 text-sm">Nhóm mục tiêu<select className={selectClass} value={item.group} onChange={(event) => update(index, { group: event.target.value as Criterion["group"] })}><option value="A">A. Nhiệm vụ trọng tâm</option><option value="B-I">B.I. Theo chức năng</option><option value="B-II">B.II. Kiểm soát ngành dọc</option></select></label>
                  <label className="space-y-1 text-sm">Tỷ trọng (%) <span className="text-primary">*</span><Input required type="number" min="0.01" max="100" step="0.01" value={Math.round(item.weight * 10000) / 100} onChange={(event) => update(index, { weight: Number(event.target.value) / 100 })} /></label>
                  <label className="space-y-1 text-sm sm:col-span-2">Mục tiêu <span className="text-primary">*</span><Input required value={item.goal} onChange={(event) => update(index, { goal: event.target.value })} placeholder="Nhập mục tiêu nhiệm vụ" /></label>
                  <label className="space-y-1 text-sm">Chỉ số đo lường KPI <span className="text-primary">*</span><Input required value={item.kpi} onChange={(event) => update(index, { kpi: event.target.value })} placeholder="Nhập chỉ số đo lường" /></label>
                  <label className="space-y-1 text-sm">Đơn vị đo<Input value={item.unit} onChange={(event) => update(index, { unit: event.target.value })} placeholder="$, số lượng, %, điểm…" /></label>
                  <label className="space-y-1 text-sm sm:col-span-2">Phương pháp đo<Input value={item.method ?? ""} onChange={(event) => update(index, { method: event.target.value })} placeholder="Công thức hoặc mô tả cách tính" /></label>
                  <div className="space-y-1 text-sm"><div>Ngày bắt đầu</div><div className="text-muted-foreground">{item.startDate ?? "—"}</div></div>
                  <div className="space-y-1 text-sm"><div>Ngày hoàn thành</div><div className="text-muted-foreground">{item.endDate ?? "—"}</div></div>
                  <label className="space-y-1 text-sm sm:col-span-2">Kết quả thực hiện<Input value={item.result} onChange={(event) => update(index, { result: event.target.value })} placeholder="Nhập kết quả (nếu có)" /></label>
                  <div className="grid grid-cols-3 gap-3 sm:col-span-2">{(["t", "b", "s"] as const).map((key) => <label key={key} className="space-y-1 text-sm">Chỉ tiêu {key.toUpperCase()}<Input value={item.target[key]} onChange={(event) => update(index, { target: { ...item.target, [key]: event.target.value } })} /></label>)}</div>
                </div>
              </div>)}
            </div>
            <Button type="button" variant="outline" className="mt-3" onClick={() => setCriteria((current) => [...current, { ...blankCriterion(), weight: 0 }])}><Plus />Thêm mục tiêu</Button>
          </section>
          {error && <p role="alert" className="text-sm text-primary">{error}</p>}
        </div>
        <div className="flex justify-end gap-2 border-t px-6 py-4"><Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Hủy</Button><Button type="submit"><Plus />Tạo đánh giá</Button></div>
      </form>
    </DialogContent>
  </Dialog>;
}