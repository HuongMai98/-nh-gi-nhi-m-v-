# Tasks
- [x] Add mockup submission to QLTT and in-app notification.
- [x] Add QLTT scoring and save/complete flow with preview role switching.
- [x] Verify employee submission, notification opening, and saved manager scores end to end.
- [x] Make task start/completion dates read-only in evaluation screens and preserve them on save.
- [x] Verify date preservation and remaining editable fields.
- [x] Replace evaluation list unit column with performer, assigning unit, and performing unit.
- [x] Allow the mockup's current performer to edit and save self-evaluation scores.
- [x] Verify list and self-evaluation navigation and tests.