<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep mockup evaluations in the root EvaluationProvider's React state so newly created records remain available across list and detail navigation without persistent storage or server mutations.
- Treat evaluation owner as the work performer and unit as the performing unit; shared assigning-unit metadata keeps list labels consistent without duplicating records.
- Resolve the preview performer through mockPerformerFor on pending self-evaluations and use the same owner gate in list, detail, and EvaluationProvider; this previews the performer's workflow without claiming authentication.
- Preserve missing manager scores instead of copying self scores; use managerEvaluationTotal for consistent pending-state totals across list and detail.
- Keep the creation form in CreateEvaluationDialog and reuse the shared design-system controls to preserve the existing vOffice presentation.
- Prebundle the creation form's Radix and variant dependencies in Vite so late optimization does not replace the browser's React dependency graph during editing.
- Preserve task-owned criterion dates when saving evaluation descriptions; evaluation forms display these values without editing them so task data remains the source of truth.
- Keep evaluation context and its hook outside the provider component module and retain context identity in Vite HMR data when that module updates; never cache evaluation records globally or share SSR user state.
- Keep preview role, self-submission notifications, and manager scoring in EvaluationProvider state; pure transitions in evaluation.ts validate handoffs so this mockup needs no real messaging or auth services.
- Insert manager review between self and office; submission locks self scores and manager completion returns the record to the existing aggregation workflow.
